---
id: caedb717-af67-470e-8350-ca956344a656
type: architecture
tags: [desktop, tauri, rust, ipc, processes, operating-system]
related_files: []
confidence: 1
---
# Desktop Tauri Rust Process and OS Bridge

## Summary
The Tauri/Rust layer is the privileged desktop host. It exposes a large explicit command registry to React, supervises the Python agent and local proxy/MCP/editor sidecars, owns PTYs and native windows, bridges browser and meeting facilities, and normalizes platform differences. JavaScript should request privileged operations through these commands rather than bypassing the host. Process ownership and shutdown order are more important than individual spawn calls: every long-lived child needs a s

## Details

# Desktop Tauri Rust Process and OS Bridge

## Summary

The Tauri/Rust layer is the privileged desktop host. It exposes a large explicit command registry to React, supervises the Python agent and local proxy/MCP/editor sidecars, owns PTYs and native windows, bridges browser and meeting facilities, and normalizes platform differences. JavaScript should request privileged operations through these commands rather than bypassing the host. Process ownership and shutdown order are more important than individual spawn calls: every long-lived child needs a single supervisor and a deterministic teardown path.

## Details

### Composition root

`src-tauri/src/lib.rs` declares modules, installs plugins, creates managed state, registers Tauri commands, wires menus/windows/events, and starts background services. The command surface is intentionally explicit and broad because distinct modules own files, Git, PTY, editor, browser, audio, meetings, Kubernetes, agents, plugins, and system integration.

Before adding a command:

1. Find the module that owns the resource.
2. Define typed request/response/error behavior there.
3. Register it once in the `generate_handler!` list.
4. Ensure the relevant Tauri capability allows only the required frontend surface.
5. Add lifecycle and platform tests when it starts a process or creates a window.

Duplicate command names or shadow execution paths are architecture errors, not conveniences.

### Runtime topology

The desktop application coordinates several runtime classes:

- Tauri/Rust host: native process and privilege boundary.
- Python native agent: JSON-lines protocol over a localhost TCP connection, supervised by Rust.
- Bun/JavaScript LLM proxy: local Unix-domain or platform-equivalent transport, supervised by Rust.
- Node MCP workers: stdio child processes, with Rust proxying calls/events to the frontend.
- code-server/editor services: supervised and embedded through the editor proxy.

Each runtime has separate failure and restart semantics. “Backend is ready” must mean the transport handshake succeeded, not merely that a child process exists.

### Agent and sidecar lifecycle

`backend.rs` and `agent.rs` own Python backend startup, connection, event forwarding, interruption, and shutdown. Session tasks are tracked so a UI close or project switch can cancel the correct work without killing unrelated windows. `process_supervisor.rs`, `proc_reap.rs`, and platform-specific process helpers prevent orphaned process trees.

`llm_proxy.rs` starts and authenticates the local provider-translation proxy. `mcp_worker.rs` starts MCP server processes; `mcp_proxy.rs` forwards tool/list requests and structured results. `vscode.rs` and its submodules manage code-server binaries, ports, and state. PTY ownership lives in `pty.rs`, not in React terminal components.

Never let both frontend and Rust independently execute the same requested tool. The frontend may gather approval or render state, but exactly one host/runtime path owns execution and result emission.

### Native feature modules

The Rust tree separates resource domains:

- Browser/webview: `browser_api/`, `webview.rs`, capture and platform webview modules.
- Windows and sessions: `window_manager.rs`, `session_window.rs`, notification and Buddy panel modules.
- Audio/meetings: `audio_capture.rs`, `meeting.rs`, `meeting_monitor.rs`, platform audio modules.
- Terminal/editor: `pty.rs`, `vscode/`, `workbench_clipboard.rs`, LSP modules.
- System/cloud: `kubectl.rs`, AWS modules, screenshot/native input, cron and monitors.
- Plugins/resources: `plugin_fs.rs`, `plugin_verify.rs`, `knowledge_fs.rs`, `vercel_skills.rs`.
- Updates/platform policy: macOS dock/audio modules, Windows update/jump-list/process-job modules.

This separation is a good first filter for code ownership, even though `lib.rs` remains the composition root.

### Platform invariants

Windows and macOS behavior cannot be inferred only from the build host. Follow existing compile-time and runtime platform gates:

- Use process-group termination on Unix and process-tree/job-object semantics on Windows.
- Pass command arguments as arrays; shell quoting differs, especially through Windows command shells.
- Do not rely solely on browser platform strings inside WebView2.
- Native menu shortcuts on macOS can intercept key events before React.
- Window and webview APIs differ for focus, transparency, capture, and decoration.

`CLAUDE.md` captures many incident-derived traps, but concrete module implementations and tests remain authoritative.

### Security boundary

Tauri capabilities define which windows can invoke privileged commands. Additional capability tokens protect browser control, browser callbacks, and the local LLM proxy. These tokens are separate because compromise of one channel must not automatically authorize another.

Protected-path checks, approval state, tool policy, and native command validation are cumulative. A more privileged downstream layer may tighten a request; it must not silently loosen an upstream denial.

### Shutdown and recovery

Use application shutdown coordination rather than relying on child exit when the window closes. Relevant modules include `app_shutdown.rs`, backend/proxy supervisors, PTY registries, webview cleanup, task registries, and process reaping. Recovery paths must clear stale ports/sockets and distinguish expected interruption from a crash visible to the user.

## Key Decisions

- Rust is the single owner of privileged OS access and long-lived desktop child processes.
- Register commands explicitly and keep execution ownership singular.
- Treat transport readiness, process existence, and application readiness as different states.
- Build cross-platform behavior by construction through platform modules and compile/runtime gates.
- Use independent capabilities for independent local trust channels.

## Constraints

- The command registry is large; search both the command implementation and `lib.rs` registration before adding anything.
- Killing a direct child may leave grandchildren alive, particularly for shells, editor services, and Windows processes.
- Tauri window events can target one window or all windows; target choice must be deliberate.
- Bundled sidecar paths differ between development and packaged builds.
- Capability or packaging changes may require updates in Tauri configuration and release checks, not only Rust code.
