---
id: e5fcb071-8f36-464f-ad2b-c5509059a531
type: integration
tags: [aws-vault, eks, kubectl, credentials, keychain, windows, macos, linux, cluster-access]
related_files: []
confidence: 1
---
# Connecting to an EKS cluster from a local developer machine (aws-vault)

## Summary
On a local developer machine (aws-vault on PATH, no pod-credential env vars), kubectl cannot reach an EKS cluster on its own: the kubeconfig's auth calls `aws eks get-token`, which needs AWS credentials in the environment. Every cluster command must be wrapped as `aws-vault exec <profile> -- kubectl --context <context> <args>`. A bare kubectl fails with NoCredentials / "exec: executable aws failed with exit code 253" — that is a missing wrapper, not a broken cluster. The profile, the credential-

## Details
# Connecting to an EKS cluster from a local developer machine (aws-vault)

## Summary
On a local developer machine (aws-vault on PATH, no pod-credential env vars), kubectl cannot reach an EKS cluster on its own: the kubeconfig's auth calls `aws eks get-token`, which needs AWS credentials in the environment. Every cluster command must be wrapped as `aws-vault exec <profile> -- kubectl --context <context> <args>`. A bare kubectl fails with NoCredentials / "exec: executable aws failed with exit code 253" — that is a missing wrapper, not a broken cluster. The profile, the credential-store backend (macOS keychain name, pass store, wincred, file) and the kubectl context name all DIFFER per developer and per machine and must be discovered, never assumed. If discovery is ambiguous or auth fails twice, ask the user rather than guessing again.

## Details
## Am I local or in a sandbox?

Applies when `aws-vault` is on PATH and there are NO pod-credential env vars (`AWS_ROLE_ARN`, `AWS_WEB_IDENTITY_TOKEN_FILE`, `AWS_CONTAINER_CREDENTIALS_FULL_URI`). If those ARE set you are in a pod: credentials come from its IAM role, aws-vault is not used, and kubectl runs directly.

POSIX probe:
`command -v aws-vault >/dev/null && [ -z "$AWS_ROLE_ARN$AWS_CONTAINER_CREDENTIALS_FULL_URI" ] && echo LOCAL || echo SANDBOX`

## The wrapper rule

```
aws-vault exec <profile> -- kubectl --context <context> <args>
```

## Discover, do not assume — three machine-specific values

1. **Profile** — `aws-vault list`. Names vary per developer/account. Several plausible candidates → ask which.
2. **Backend / keychain** — the credential store often has to be named via an environment variable. On macOS the Keychain name is frequently `login`, but that is NOT guaranteed (a dedicated `aws-vault` keychain, or `pass` / `file` / `wincred` / `kwallet` / `secret-service`). An unset or wrong backend makes a perfectly valid cached session invisible and produces a misleading "credentials missing".
3. **Context** — `kubectl config get-contexts`. The kubeconfig may hold friendly aliases (e.g. `us-prod`) or full cluster ARNs. Passing an ARN when an alias is configured fails with `context "arn:aws:eks:..." does not exist` — a naming mismatch, not an access problem.

## Find the real values in the developer's own helper

Most developers have a script/alias that already encodes profile + backend.

- POSIX: `grep -rn "aws-vault" ~/.zshrc ~/.bashrc ~/.zprofile ~/.profile 2>/dev/null`, then read the script the alias points at.
- Windows PowerShell: `Select-String -Path $PROFILE -Pattern "aws-vault"`

Reuse THAT script's values — it is where the machine-specific `AWS_VAULT_KEYCHAIN_NAME` / `AWS_VAULT_BACKEND` and the default profile live.

## Sessions are cached; a missing session looks like missing credentials

```
aws-vault: error: exec: Error getting temporary credentials: profile <p>: credentials missing
```

Re-check the backend variable first. Only if that does not help, ask the user to run their warm-up helper (MFA) and report back. Do not loop retrying. `aws-vault list` shows a live session in the Sessions column.

## Platform-specific invocation

**macOS / Linux (bash, zsh)**
```bash
export AWS_VAULT_KEYCHAIN_NAME=<backend-name-if-required>   # verify, don't assume
aws-vault exec <profile> -- aws sts get-caller-identity
aws-vault exec <profile> -- kubectl --context <context> get pods -n <ns>
```
Each shell invocation is independent — export the variable in the SAME command as the call.

**Windows PowerShell**
```powershell
$env:AWS_VAULT_BACKEND = "wincred"        # typical on Windows; confirm with the user
aws-vault exec <profile> -- aws sts get-caller-identity
aws-vault exec <profile> -- kubectl --context <context> get pods -n <ns>
```

**Windows cmd.exe**
```bat
set AWS_VAULT_BACKEND=wincred
aws-vault exec <profile> -- kubectl --context <context> get pods -n <ns>
```

Other variables that may apply: `AWS_VAULT_BACKEND` (keychain | wincred | pass | file | secret-service | kwallet), `AWS_VAULT_FILE_PASSPHRASE`, `AWS_VAULT_PROMPT` (osascript | terminal | ykman | …). Ask which applies rather than cycling through them.

## Prove auth first

`aws-vault exec <profile> -- aws sts get-caller-identity` returning the expected account/ARN means credentials are good; any cluster error after that is a real cluster/RBAC/context issue.

## Ask the user when any of these are unclear

- `aws-vault list` shows several plausible profiles.
- The credential store / backend is unknown (keychain name, pass store, file passphrase).
- `kubectl config get-contexts` has no obvious match for the cluster named.
- Auth fails twice with the same error after a corrected attempt.
- A session needs warming (MFA) — only the human at the keyboard can do that.

## Gotchas observed

- `timeout` is not installed by default on macOS — do not wrap commands in it.
- `AccessDenied` on `aws eks get-token` / `describe-cluster` → the identity lacks `eks:DescribeCluster` or an EKS access entry. Setup gap; surface it.
- Kubernetes `Forbidden` after valid AWS auth → RBAC is read-only or unmapped for that action.
- Cross-account clusters need an assume-role config AND a target-cluster access entry.
- `kubectl cp` into an image with a non-writable app directory fails with `tar: Exiting with failure status`; pipe a base64 payload into `/tmp` instead, and set `NODE_PATH` when the script needs the app's own modules.
- Default to read-only verbs; mutations need explicit owner approval.

## Key Decisions
Never hard-code a profile name, keychain name or context — discover them. Prove auth with `aws sts get-caller-identity` BEFORE concluding anything about the cluster, so an auth problem is never misreported as a cluster outage. Treat "credentials missing" as a probable unnamed/incorrect backend first, before asking the user to re-do MFA. An agent can never complete MFA itself — that step belongs to the human at the keyboard.

## Constraints
Defaults to read-only verbs; mutations (apply, delete, scale, exec, port-forward) need explicit owner approval because there is no MFA backstop once a session is warm. Cross-account clusters need both an assume-role config and a target-cluster EKS access entry; missing either makes the cluster unreachable and that gap must be surfaced, not improvised around.
