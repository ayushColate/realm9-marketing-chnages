---
id: 63df6a93-eab2-4023-aedc-45e0f3c24f9d
type: integration
tags: [desktop, llm, routing, providers, proxy, translation]
related_files: []
confidence: 1
---
# Desktop LLM Routing Proxy and Provider Translation

## Summary
Desktop model selection is a route, not just a model name. The live tab carries backend, provider configuration, model, and credential mode. The Python agent resolves that route and either calls a direct provider/client path or sends an OpenAI-compatible request through the Rust-supervised local LLM proxy. The proxy’s translation layer is vendored from `cana-web/api/src/services/translate`; web is canonical, the source revision is pinned, and desktop changes must be synchronized rather than inde

## Details

# Desktop LLM Routing Proxy and Provider Translation

## Summary

Desktop model selection is a route, not just a model name. The live tab carries backend, provider configuration, model, and credential mode. The Python agent resolves that route and either calls a direct provider/client path or sends an OpenAI-compatible request through the Rust-supervised local LLM proxy. The proxy’s translation layer is vendored from `cana-web/api/src/services/translate`; web is canonical, the source revision is pinned, and desktop changes must be synchronized rather than independently invented.

## Details

### Routing inputs and precedence

The effective route can be influenced by:

- Per-tab backend and selected provider/model configuration.
- Global AI settings and backend defaults.
- Enabled model catalogue returned by the hosted platform.
- Local provider definitions synchronized into the in-memory proxy registry.
- Runtime-specific defaults and model capability metadata.
- Explicit command/run overrides for one action.

The tab-local route is load-bearing: using only a global model caused tabs to call disabled or mismatched models. `chat-tab-store.ts`, `chat-tab-seed.ts`, `src/lib/store.ts`, and `agent-session.ts` preserve and seed route state. Safe seed precedence is recent valid per-chat choice, then global settings, then backend defaults; hidden or non-seedable runtimes must not leak into a new tab.

A bare model display name may be ambiguous across providers. Prefer provider/model codes or a pinned configuration identity when supported.

### Python provider abstraction

`src-agent/llm/` contains provider adapters, response normalization, streaming, model capabilities, and routing helpers. `model_config_client.py` retrieves hosted catalogue/config state; `model_defaults.py` protects offline and initial defaults. The agent loop consumes a common stream/tool-call shape while preserving provider-specific usage and error information needed for retry and context accounting.

Provider errors should remain typed enough to distinguish authentication, policy denial, unsupported capability, context overflow, quota/rate limit, transient upstream failure, and malformed translation. Blindly retrying all errors can double spend or hide configuration faults.

### Local proxy lifecycle and authentication

`src-tauri/src/llm_proxy.rs` supervises the local proxy process and gives it a capability credential and local transport address. The proxy registry is in memory; after a proxy restart, the React app polls readiness and resynchronizes local provider definitions. Process started and provider registry ready are different states.

The capability credential is private to the app/proxy channel. It must not be placed in browser content, logs, persistent knowledge, or connector schemas. The proxy should bind to a local-only transport and validate the capability on every request.

### Translation ownership

The canonical multi-provider translation implementation lives at `cana-web/api/src/services/translate/`. It handles request serialization, response parsing, streamed event conversion, tool calls, prompt caching, provider-specific thinking/reasoning shapes, upstream dispatch, and error propagation.

Desktop vendors this source into `src-llm-proxy/src/translate/`. The contract is:

1. Fix translator behavior in `cana-web` first.
2. Run the desktop sync command (`npm run llm:sync-web`, implemented by `scripts/sync-llm-proxy-from-web.mjs`).
3. Update `.translate-source-sha` through the sync flow.
4. Run desktop proxy/build tests and relevant web translation tests.
5. Never patch the vendored directory as the sole source of a fix.

At the verified snapshot, the pinned desktop source revision lagged newer web translation commits. Treat this as a drift warning and compare the pin before provider work.

### Context windows and capability catalogues

Model context windows, tool support, image support, reasoning modes, and token-accounting behavior are data, not reliable naming heuristics. Use the enabled catalogue and capability metadata. Keep frontend defaults, Python defaults, proxy/provider definitions, and hosted catalogue behavior aligned through tests.

The agent’s context manager should consume observed usage from translated/provider responses. A translation change that drops usage fields can silently degrade compaction decisions even when text generation still works.

### Direct, cloud, and local routes

Routes differ in credential and network ownership:

- Hosted/platform route: desktop authenticates to Cana; the server resolves provider policy and credentials.
- Local proxy route: desktop owns a local provider configuration and proxy capability; the sidecar calls the upstream.
- Runtime-native route: Claude/remote runtimes may own their model protocol and session state separately.

Backend switching is a deliberate context handoff. Ordinary sends should not attach a redundant frontend transcript because each backend owns its own conversation.

### Verification hotspots

Desktop tests cover model defaults/capabilities, proxy transport, runtime labels, configuration diagnostics, and stream resilience. Web tests under `api/src/services/translate/**/__tests__` cover parsers, serializers, SSE, prompt caching, upstream selection, errors, liveness, concurrency, and incident replays. Translation changes should run both sides when the vendored copy changes.

## Key Decisions

- Treat backend/provider/model/configuration as one route and persist it per tab.
- Keep the local proxy supervised and capability-authenticated.
- Make `cana-web` the only source of truth for provider translation.
- Synchronize local provider state after every proxy restart.
- Preserve usage and capability metadata through normalization, not only text/tool calls.

## Constraints

- Provider APIs evolve independently and may represent streaming, reasoning, tool calls, and errors differently.
- Local credentials must never cross into renderer logs or persisted knowledge.
- A valid model name can still be unavailable under the selected configuration or access policy.
- Vendored source can compile while drifting behaviorally; revision-pin checks and cross-repo tests are necessary.
- Backend switches may require explicit history handoff, while ordinary sends must avoid duplicate history.
