---
id: c5a113ad-273e-4be9-8c67-2478902baf2b
type: architecture
tags: [web, monorepo, nextjs, express, packages, routing]
related_files: []
confidence: 1
---
# Cana Web Monorepo Web API and Package Boundaries

## Summary
`cana-web` is a pnpm/Turbo workspace containing an Express API, a Next.js application, and shared packages. Production packages both Node services into one container and runs them as sibling processes on separate ports. Kubernetes Services and an explicitly ordered ingress decide whether a URL reaches Next or Express. Therefore filesystem route existence alone does not establish production ownership: application mount order, Next middleware/matchers, and enterprise ingress prefixes form one cont

## Details

# Cana Web Monorepo Web API and Package Boundaries

## Summary

`cana-web` is a pnpm/Turbo workspace containing an Express API, a Next.js application, and shared packages. Production packages both Node services into one container and runs them as sibling processes on separate ports. Kubernetes Services and an explicitly ordered ingress decide whether a URL reaches Next or Express. Therefore filesystem route existence alone does not establish production ownership: application mount order, Next middleware/matchers, and enterprise ingress prefixes form one contract.

## Details

### Workspace topology

`pnpm-workspace.yaml` includes:

- `api`: Express service, long-lived bridges, workers, hosted agent runtime, translation.
- `web`: Next.js dashboard, admin, authentication, hosted/public surfaces, route proxies/actions.
- `packages/*`: database/shared domain package, public SDK, private embed bundle, and related packages.

`mobile/` is deliberately outside the workspace. It is a Capacitor wrapper with its own npm lockfile/toolchain and should not be added to Turbo or the production Docker build accidentally.

Root `turbo.json` makes builds dependency-aware and defines scoped translation/session test tasks. The root package manager version is pinned. Security dependency overrides are centralized at root and should be reviewed before loosening child constraints.

### Express responsibilities

`api/src/index.ts` is the composition root. It mounts many routers, WebSocket bridges, error handling, operational metrics, graceful drain, schema guards, recovery/sweeper jobs, and schedulers.

Ordering is security- and protocol-sensitive:

- Public share/preview routes mount before authenticated catch-alls.
- Raw-body webhook/HMAC routes mount before JSON parsing where exact bytes matter.
- Specific authentication schemes mount before general routers.
- Bus and boards routes retain dual agent/user authentication and cannot be wrapped blindly in ordinary user JWT middleware.
- Desktop Apps and synchronization endpoints are pinned to Express because desktop sends bearer credentials and requires CORS.
- The four-argument Express error handler is last.

WebSocket bridges are attached to the same HTTP server after listen. Graceful drain marks readiness false and controls termination, so a probe must target the drain-aware endpoint.

### Next.js responsibilities

`web/app/` contains grouped auth, dashboard, admin, and organization-admin pages plus public hosted Apps, embed bundle serving, shared artifacts, and marketing. NextAuth is owned by Next. Server actions and route handlers handle cookie-authenticated dashboard workflows and frequently proxy to Express with server-derived credentials.

`web/middleware.ts` owns:

- Root routing for authenticated browser and Capacitor user agents.
- No-store policy for sensitive WebView entry/login routes.
- Per-App CSP for hosted pages.
- Desktop CORS on selected route prefixes.
- Auth protection for dashboard groups.

The middleware matcher must include every CORS prefix; an allowlist entry without a matcher never runs.

### Shared packages

`packages/db` exports Prisma, RBAC, audit, usage, Apps, OAuth, boards, and connection helpers. Its `package.json` export map is a runtime-deployment contract: the runtime build script derives entry points from exports so a new subpath is compiled rather than shipping raw TypeScript.

`packages/sdk-js` is the public `@cana-ai/sdk`. It exposes OpenAI-compatible, agent/run, UI, signing/issuer, and type surfaces; package-boundary and UI-catalog tests protect publishes. React support is optional rather than forcing it on server consumers.

`packages/embed-js` is private and built into a browser bundle served by a Next route. Docker copies its output explicitly because standalone tracing did not reliably include it.

### Production process model

`Dockerfile` builds dependencies and bounded runtime trees, then `entrypoint.sh` starts both:

- Express on the API port.
- Next standalone server on the web port.

If either process exits, the entrypoint terminates the other and exits with the failed status. The same pod backs two Kubernetes Services selecting the same labels. This saves deployment duplication but means one process failure makes the pod unhealthy as a whole.

Database migration is intentionally absent from the entrypoint and belongs to the Helm PostSync job. Transitional seed behavior remains in the entrypoint; deployment configuration must explicitly retire it when the migration hook owns seeding.

### Ingress is part of route ownership

`cana-web-enterprise/charts/cana-web/templates/ingress.yaml` is a long ordered prefix map. Cookie-authenticated Next routes and direct bearer-authenticated Express routes coexist under `/api`. More-specific prefixes must precede broad prefixes. Some large upload routes bypass Next due to byte-integrity behavior; some dashboard routes must reach Next because only it resolves session cookies.

When adding a route, verify all of:

1. Express or Next implementation and local mount order.
2. Authentication model expected from each caller.
3. Next middleware/CORS matcher when browser/desktop relevant.
4. Enterprise ingress service/prefix.
5. Docker/runtime inclusion of any package output.
6. Contract tests for route ownership.

### Mobile boundary

The Capacitor app loads the hosted bare origin; its bundled `www` is an offline fallback. The server uses a user-agent marker for mobile routing/session policy. The bare server URL, native keyboard/inset configuration, and OAuth cookie behavior are load-bearing iOS/Android constraints.

## Key Decisions

- Keep Express and Next as separate processes with explicit per-route ownership.
- Package them into one pod but fail the pod when either process fails.
- Make enterprise ingress and Next middleware part of the application route contract.
- Derive shared-package runtime builds from the export map.
- Keep mobile outside pnpm/Turbo and make it a thin hosted-WebView wrapper.

## Constraints

- A locally working route can 404 or authenticate incorrectly in production if ingress points to the other process.
- Prefix order and raw-body parser order can alter security behavior.
- Next standalone output may omit dynamically served package artifacts unless copied explicitly.
- Both Node processes load the database package and allocate their own pools.
- Historical package names still use earlier product naming; do not infer current repository ownership from package names alone.
