---
id: 140fd9f3-145f-4485-ac12-46e9a8c26700
type: implementation
tags: [site-onboarding, tracking, google-analytics, search-console, permissions]
related_files: [src/app/(dashboard)/sites/sites-list.tsx, src/app/api/sites/route.ts, src/app/(dashboard)/sites/[siteId]/settings/site-settings.tsx, src/app/(dashboard)/sites/page.tsx]
confidence: 1
---
# Syngy site onboarding and tracking lifecycle

## Summary
Organization admins create a site with a name and bare production domain. Syngy generates a unique tracking ID; Settings → General displays its script tag. A site changes from `No data yet` to `Tracking active` after non-internal visitor activity is received, while GA and GSC are optional integrations.

## Details
# Syngy site onboarding and tracking lifecycle

## Summary
Organization admins create a site with a name and bare production domain. Syngy generates a unique tracking ID; Settings → General displays its script tag. A site changes from `No data yet` to `Tracking active` after non-internal visitor activity is received, while GA and GSC are optional integrations.

## Details
## Creation
- Site creation is gated by Origin9 permission `org:settings:write` in both UI and `POST /api/sites`.
- Required fields are `name` and `domain`.
- Domain normalization removes `http://` or `https://` and trailing slashes; the API validates a bare hostname.
- Duplicate domains are refused within the same organization.
- Creation generates a UUID tracking ID and makes the creator the site owner.

## Tracking installation
- Settings → General renders `<script src="{platformUrl}/t.js" data-site="{trackingId}" async></script>`.
- The snippet is installed once in the website’s shared/global head so it loads on public pages.
- The unique `data-site` value routes events to the correct Syngy site and must not be reused for another site.

## Verification
- Sites list shows `No data yet` before any non-internal visitor is recorded.
- Activity within the last 48 hours displays `Tracking active`; older activity displays a quiet-duration status.
- A practical check is to publish the script, visit the public website in a clean/private session, then refresh Syngy after ingestion.

## Optional integrations
- Settings → Integrations supports Google Analytics and Google Search Console OAuth connections.
- Settings → Traffic Filtering stores internal email domains so identified employee traffic can be excluded by default.

## Key Decisions
Onboarding guidance inside `/sites` starts at site creation, not account creation. Explain the bare-domain requirement before submission and place installation/verification steps in the contextual Instructions sheet.

## Constraints
Only org admins can create sites. The exact tracking tag is site-specific and only available after creation. GA and GSC are optional and require accounts with access to the correct properties.
