---
id: 9125d1f6-a312-420e-9943-2b8529b1f7ce
type: implementation
tags: []
related_files: []
confidence: 1
---
# architecture--chat-attachments-inline-injection-not-tool-calling

## Summary
Chat file attachments are delivered to the LLM by injecting extracted text directly into the user message at request time — not via list_attachments / read_attachment tool calls. The model sees full file content before the user's question, eliminating the chicken-and-egg problem where the LLM would need to know what to fetch before it has seen the content. Conversation history carries the injected content forward on subsequent turns automatically.

## Details
---
id: 81deed65-3436-4523-b989-f36d6877c33a
type: architecture
tags: [chat, attachments, file-upload, inline-injection, tool-calling, llm-context, architecture]
related_files: [api/src/routes/chat.ts, api/src/services/builtin-tools.ts, api/src/services/chat-tool-loop.ts, packages/db/prisma/schema.prisma (ChatAttachment, ChatAttachmentPage models), api/src/services/attachment-extract.ts, api/src/services/attachment-store.ts]
confidence: 1
---
# architecture--chat-attachments-inline-injection-not-tool-calling

## Summary
Chat file attachments are delivered to the LLM by injecting extracted text directly into the user message at request time — not via list_attachments / read_attachment tool calls. The model sees full file content before the user's question, eliminating the chicken-and-egg problem where the LLM would need to know what to fetch before it has seen the content. Conversation history carries the injected content forward on subsequent turns automatically.

## Details
## How it works

When a request arrives at `POST /api/chat/completions` with attachment ids in the `X-Cana-Chat-Attachments` header:

1. **Ownership validation** — `prisma.chatAttachment.findMany` verifies the ids belong to the authenticated user and have `extractStatus = 'ready' | 'skipped_binary'`. Returns 400/409 on failure.

2. **Strip `file` content parts** — All messages are scanned and any `{ type: "file" }` content parts are filtered out before forwarding to the upstream provider (no provider accepts them).

3. **Fetch page text** — For each validated attachment, `prisma.chatAttachmentPage.findMany` retrieves rows ordered by `pageNumber`. Pages are concatenated with `\n\n`.

4. **Budget enforcement** — `INLINE_PER_ATTACHMENT_CHARS = 40_000` per file, `INLINE_TOTAL_CHARS = 120_000` across all files in a single request. Truncated files get a trailing note: `[Content truncated at N characters — the file continues beyond this point.]`

5. **Format as XML** — Each file becomes an `<attachment name="filename.ext">…text…</attachment>` block.

6. **Prepend to last user message** — The assembled prefix is prepended to `messages[lastUserIndex].content` — either string-concatenated (for string content) or prepended as a `{ type: "text" }` part (for array content).

7. **Attachment claiming** — Attachments are bound to the session+message via `prisma.chatAttachment.updateMany` (sets `sessionId`, `messageId`, `claimedAt`) so they show up on page reload.

## Why tool-calling was rejected

The original approach exposed `list_attachments` and `read_attachment` as always-available built-in tools and let the LLM decide when to call them. This was rejected because:

- **Chicken-and-egg**: the LLM needs to see file content to know what questions to ask about it, but it can only fetch content after deciding it wants to. The first turn always produced worse results.
- **Extra latency**: every attachment required at least one round-trip tool call before the model could answer.
- **Accuracy**: leaving fetch decisions to the model under tool-use constraints produced inconsistent behavior across providers.

## Follow-up turn behavior

Once the injected content lands in the persisted `ChatMessage` row for the user's turn, it is replayed back in the conversation history on subsequent turns — the model sees the full file content again without any extra work. No special handling is needed for follow-up questions about the same file.

## Binary / failed files

`extractStatus = 'skipped_binary'` or `'failed'` files get a placeholder block: `[No text content could be extracted from this file.]` instead of being skipped silently — the model can tell the user the file couldn't be read.

## Key Decisions
- **Inline injection over tool-calling**: teammate code review identified that tool-calling requires the model to know what to fetch before fetching, which gives poor accuracy on the first turn. Inline injection removes this constraint entirely.
- **Budget constants (40k/file, 120k/session)**: chosen to stay within typical context windows while leaving room for conversation history and system prompts. Not user-configurable — hardcoded in `chat.ts`.
- **XML `<attachment>` wrapper**: makes it easy for the model to distinguish file content from the user's question, and makes the boundary unambiguous even if the file contains markdown or code.
- **Prepend to last user message, not system prompt**: injects at the point where the user's question is — the model reads files first, then the question, which mirrors how a human would skim a document before answering.
- **Attachment claiming happens before injection**: the `prisma.chatAttachment.updateMany` (bind to session+message) runs before text injection so the user-visible persisted message is clean (no injected text).
- **`list_attachments` / `read_attachment` removed from ALWAYS_AVAILABLE**: these built-ins were removed to prevent the model from attempting the old tool-call path in parallel with the new inline approach. The handler code remains in `builtin-tools.ts` as dead code but compiles cleanly.
- **Tool loop no longer required for attachments**: the routing condition `if (enabledConnectors || builtinPacksHeader || hasSkills)` no longer includes attachment ids — the simple `translateAndForward` path handles attachment turns fine.

## Constraints
- Attachment ids must be validated as owned by the authenticated user before any text is fetched — never trust the header directly.
- Only attachments with `extractStatus = 'ready' | 'skipped_binary'` are allowed through; `pending` and `failed` statuses are rejected at the 409/400 gate before injection.
- The injection prefix is NOT persisted to `ChatMessage` — the raw user text is saved before injection. This keeps the user's bubble clean on page reload.
- Do NOT re-add `list_attachments` or `read_attachment` to `ALWAYS_AVAILABLE` — they conflict with the inline approach and would cause the model to try fetching content it already has.
- Do NOT route attachment-only requests through `runChatWithTools` — the simple streaming path is sufficient and avoids the overhead of MCP discovery.