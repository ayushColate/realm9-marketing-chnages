---
id: 4d2d5a4a-a833-44ef-8d85-149e5b68ecab
type: convention
tags: [knowledge-base, convention, markdown, file-naming, test-data]
related_files: [.cocreate/knowledge/note--hi-everyone.md, /Users/shashisinghrajput/colate/cana-web/web/lib/knowledge-utils.ts, /Users/shashisinghrajput/colate/cana-web/web/app/(dashboard)/knowledge/knowledge-client.tsx]
confidence: 1
---
# Knowledge markdown file format and slug naming convention used for .cocreate/knowledge entries

## Summary
Knowledge items in this project are plain markdown files under .cocreate/knowledge/, named `<type>--<slug>.md` and structured as `# Title` followed by `## Summary` and optional `## Details`, `## Key Decisions`, `## Constraints` sections. The format is not arbitrary: it is the exact shape produced and parsed by cana-web's knowledge-utils helpers, so hand-written files must match it or they will not parse. This entry was created while adding a deliberately fake sample item (`note--hi-everyone.md`)

## Details
# Knowledge markdown file format and slug naming convention used for .cocreate/knowledge entries

## Summary
Knowledge items in this project are plain markdown files under .cocreate/knowledge/, named `<type>--<slug>.md` and structured as `# Title` followed by `## Summary` and optional `## Details`, `## Key Decisions`, `## Constraints` sections. The format is not arbitrary: it is the exact shape produced and parsed by cana-web's knowledge-utils helpers, so hand-written files must match it or they will not parse. This entry was created while adding a deliberately fake sample item (`note--hi-everyone.md`) to exercise the create/read path.

## Details
**Where entries live**

Knowledge items are markdown files in `.cocreate/knowledge/`. At the time of writing, this project contained exactly one: `note--hi-everyone.md`, a fake placeholder created on purpose as test data.

**File naming**

Filenames follow `${type}--${slug}.md`, where the slug is derived from the title by: lowercasing, stripping everything that is not `a-z0-9`, whitespace or hyphen, collapsing whitespace to hyphens, collapsing repeated hyphens, then truncating to 80 characters. A title that slugifies to an empty string (for example a fully non-Latin title) falls back to the first 12 hex characters of the title's SHA-256. So the title `hi everyone` with type `note` yields `note--hi-everyone.md`.

**Body structure**

The body is assembled in a fixed order:

```
# <Title>

## Summary
<summary>

## Details          (optional)
## Key Decisions    (optional)
## Constraints      (optional)
```

The three optional sections are appended only when non-empty, and always in that order.

**Why the exact shape matters**

Reading back is done with regexes anchored on the literal headings — `## Details\n`, `## Key Decisions\n`, `## Constraints\n`, each captured up to the next `## ` heading or end of file. Consequences for anyone writing these files by hand or generating them from another tool:

- Heading text must match exactly, including capitalisation (`## Key Decisions`, not `## Key decisions`).
- The section content must begin on the line immediately after the heading; the parser expects a single newline after the heading, not a blank line.
- The `# Title` and `## Summary` sections are not recovered by the section parser at all — they are handled separately — so a file missing `## Summary` still "parses" but carries no summary.
- Content is hashed with SHA-256 for change detection, so any whitespace difference counts as a content change. Do not reformat existing entries casually; it looks like an edit to every consumer.

**The fake entry**

`note--hi-everyone.md` is intentionally meaningless content. It was written to confirm that an item gets created, indexed and rendered. It states in its own Constraints section that it must not be used for any real decision and is safe to delete. Future agents should not treat it as project guidance, and should not "fix" or expand it into something that looks authoritative.

## Key Decisions
- **Match the generated format exactly rather than inventing a hand-written layout.** The file is read back by heading-anchored regexes; a prettier layout (blank line after the heading, different capitalisation, extra front-matter) silently yields empty sections rather than an error, which is the worst kind of failure — it looks fine and loses data.
- **Keep the sample entry obviously fake.** Test data that reads like real guidance eventually gets believed. The entry names itself as a placeholder in both its Summary and its Constraints so no human or agent mistakes it for a project decision.
- **Still give the fake entry the full standard section layout.** A stub with only a Summary would not exercise the same parsing path it was created to test, defeating the point of adding it.
- **Verify by grepping the file's own content rather than running a build.** The deliverable is a markdown document; a green test suite proves nothing about it. The check used was that the title heading is present at the start of a line.

## Constraints
- `.cocreate/knowledge/note--hi-everyone.md` is test data. Do not cite it, extend it, or derive behaviour from it; deleting it is safe.
- The format helpers themselves live in a different repository (cana-web) and are not editable from this project — this project is a consumer of the convention, not its owner. Changing the layout here without changing those helpers breaks parsing.
- The optional sections are position-sensitive: content is captured up to the next `## ` heading, so introducing a new `## ` heading of your own between them truncates the preceding section.
- Never place credentials, tokens, or environment variable values in a knowledge entry; these files are synced to the team's shared knowledge base.
