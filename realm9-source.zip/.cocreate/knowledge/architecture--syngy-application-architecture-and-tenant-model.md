---
id: cbf672bf-52ac-4765-8375-581fd1728cb1
type: architecture
tags: [nextjs, architecture, organizations, sites, prisma, origin9, tracking]
related_files: [CLAUDE.md, prisma/schema.prisma, src/app/(dashboard)/layout.tsx, src/lib/auth.ts, src/lib/rbac-org-decision.ts, tracking-sdk, proxy]
confidence: 1
---
# Syngy application architecture and tenant model

## Summary
Syngy is a Next.js App Router marketing-intelligence application organized around organizations and site-scoped workspaces. Origin9 is authoritative for identity and organization membership; PostgreSQL/Prisma stores a local Organization projection and Site data, while Redis/BullMQ handle caching and background jobs.

## Details
# Syngy application architecture and tenant model

## Summary
Syngy is a Next.js App Router marketing-intelligence application organized around organizations and site-scoped workspaces. Origin9 is authoritative for identity and organization membership; PostgreSQL/Prisma stores a local Organization projection and Site data, while Redis/BullMQ handle caching and background jobs.

## Details
## Runtime architecture
- `src/app/` contains Next.js App Router pages and REST API routes.
- `src/components/` contains domain-oriented client/server UI components.
- `src/lib/` contains authentication, authorization, Prisma, analytics, SEO, email, and integration services.
- `src/workers/` and BullMQ process asynchronous work.
- `tracking-sdk/` builds the external website tracking runtime loaded through the Syngy script tag.
- `proxy/` contains the independently deployable edge SEO rewriter.

## Tenant hierarchy
- Origin9 is authoritative for user identity, organization membership, roles, approval, and MFA.
- `Organization.externalOrgId` is the only resolution key from Origin9 to the local database.
- `Site.organizationId` is the local authoritative organization foreign key; legacy `Site.orgId` is retained during migration but is not the main access-control key.
- Most product records are site-scoped by `siteId`.
- Dashboard layout loads the signed-in session, rejects untrusted organization claims, resolves visible sites, and mounts the shared sidebar/top bar.

## Core product engines
1. Tracking SDK for visitor events and content injection.
2. Edge SEO proxy for server-side HTML rewriting.
3. Syngy dashboard for analytics, SEO, GEO, forms, campaigns, contacts, content, and settings.

## Key Decisions
Origin9 remains the source of truth for identity and organization membership. Local organization rows exist as foreign-key targets and product-state containers. Site access must remain organization-scoped and fail closed when session organization claims are missing or untrusted.

## Constraints
Do not resolve organizations by mutable labels such as name, slug, or domain. Keep browser-safe RBAC values in modules without server-only imports. Tracking SDK and edge proxy are separate deployable/build surfaces.
