---
id: c5cd87ed-c95d-46c5-b4e6-a66cc95b07fd
type: architecture
tags: [web, prisma, authentication, authorization, tenancy, audit]
related_files: []
confidence: 1
---
# Cana Web Data Model Auth Tenancy and Audit

## Summary
Cana Web uses PostgreSQL through a large Prisma schema shared by Next and Express. The schema spans identity, organizations, billing, usage, product records, chat, remote agents, Apps, bus/boards, and security/audit domains. Authentication is intentionally plural: Auth.js database sessions, Origin9 bearer tokens, API keys, internal cron handshakes, pod session tokens, App visitor credentials, and bus-agent tokens. Authorization and tenant resolution must be applied at the data boundary; acceptin

## Details

# Cana Web Data Model Auth Tenancy and Audit

## Summary

Cana Web uses PostgreSQL through a large Prisma schema shared by Next and Express. The schema spans identity, organizations, billing, usage, product records, chat, remote agents, Apps, bus/boards, and security/audit domains. Authentication is intentionally plural: Auth.js database sessions, Origin9 bearer tokens, API keys, internal cron handshakes, pod session tokens, App visitor credentials, and bus-agent tokens. Authorization and tenant resolution must be applied at the data boundary; accepting a user or organization id from model/client arguments is not authorization.

## Details

### Database package and connection model

`packages/db/prisma/schema.prisma` defines the canonical schema. The datasource omits an inline URL; runtime configuration comes from environment and Prisma adapter setup. `packages/db/index.ts` creates one `pg.Pool` per Node process and exposes a bounded credential-free pool snapshot.

Production defaults to a conservative pool maximum because both Express and Next load the package in every pod, and the cron worker adds further connections. An idle-pool error listener prevents failover errors from terminating the process. A guarded Account lookup retry/raw fallback addresses an observed transaction-pool/Prisma account-miss path; it is scoped to authentication account lookup rather than globally hiding inconsistent reads.

### Principal domains in the Prisma schema

- **Identity and tenancy:** users, accounts, database sessions, organizations, organization members, device tokens, agent identities, platform roles/permissions.
- **LLM configuration and policy:** providers, models, configurations, account pools, credentials metadata, model access, quotas, health and selection policy.
- **Usage and billing:** usage attempts/reservations/counters/records/rollups, plans, groups, subscriptions, invoices, webhook idempotency.
- **Product management:** projects, tasks, meetings, documents and versions, knowledge items and audits.
- **Chat and remote agents:** sessions/messages/shares/attachments/files, sub-agent runs, session knowledge, connectors, snapshots.
- **Cana Apps:** application identity/configuration, signing/API keys, origins, connectors, rate limits, usage, sessions/messages/runs/events/tool calls/evidence/checkpoints/forms/webhooks/experiments.
- **Bus and boards:** channels, membership/grants/messages/attachments/audit, agent tokens, device auth, boards/tasks/dependencies/events/shards.
- **Security/audit:** general audit logs, security events, credential audit, platform settings, connections, templates, skills, commands.

Refer to relations and unique indexes rather than relying on this grouping when changing constraints.

### Browser authentication with Auth.js

`web/auth.ts` configures one Origin9 OIDC provider and PrismaAdapter with database sessions. Default database session lifetime supports mobile, while `web/lib/web-session-cap.ts` applies a shorter cap for ordinary browser sessions. OAuth transient cookies use cross-site-compatible secure settings for Capacitor/WKWebView while the long-lived session cookie remains more restrictive.

The sign-in callback is product logic, not just authentication plumbing. It resolves roles/permissions through token claims and Origin9 fallbacks, updates account tokens, assigns defaults, joins eligible organizations by verified email-domain policy, or creates a personal organization. Changes require tenancy and billing review.

### Express user authentication

`api/src/middleware/auth.ts` is cookie-first:

1. If an Auth.js session cookie is present, validate it against the shared `Session` table and resolve the local user.
2. Otherwise accept an Origin9 bearer/x-api-key-shaped token and verify it against JWKS.
3. Resolve local user identity and permissions with bounded caches.
4. Emit typed session-expired/invalid errors only for definitive JWT failures so transient JWKS/database failures do not log desktop users out incorrectly.

Cookie-first behavior prevents a stale forwarded bearer from overriding a valid dashboard session and avoids multiple uncoordinated refreshers for one token family.

### Other authentication models

- API keys are hashed at rest, checked for revoke/expiry, and scoped to their owner.
- Internal cron calls require a shared internal header plus an explicit acting user id; production boot validates the secret’s presence/strength.
- Remote agent/pod calls use signed session credentials with audience and expiry constraints.
- Hosted Apps use visitor credentials plus origin allowlists and replay protection.
- Bus/boards accept either an authenticated user or a separately validated agent token where the route explicitly supports dual principals.

Do not wrap a dual-auth route with ordinary user JWT middleware before its own authenticator; doing so rejects the agent principal before the router can validate it.

### Authorization and organization scoping

`packages/db/rbac.ts` is the shared source for platform roles and permissions. Express middleware exposes single/any/organization permission requirements. Organization membership and owner resolution should be derived from authenticated `req.userId` plus database membership, not trusted from request payloads.

Data access rules should include one of:

- Direct owner field equals authenticated user.
- Organization id in the caller’s active memberships plus required permission.
- Explicit public/share token scope.
- App/session identity bound by its signing/auth middleware.
- Internal service identity with narrowly defined route and audit.

Repository/project deduplication uses normalized URL and organization scope. Personal organizations are still organizations and should follow the same scoping primitives.

### Content storage split

Large document, knowledge, chat-file, attachment, and snapshot bodies may live in S3 while PostgreSQL holds identity, metadata, hash/version, ownership, and object key. Deleting or archiving a database row and deleting object content are separate operations with sweepers/retention implications. Hash or version checks protect against stale/partial content.

### Audit and privacy

Mutating Express routes are broadly wrapped by audit middleware, with domain-specific audit/security/credential logs where needed. Audit metadata must be useful without leaking prompts, credentials, raw tokens, or private document contents. User/org/resource ids, action, result, safe request metadata, and correlation ids are generally sufficient.

Privacy/retention workers delete or archive domain data on schedules. Public/share routes must mount before authenticated catch-alls but still validate their share token and resource state.

### Migration constraints

Production uses PgBouncer for application traffic and a direct PostgreSQL endpoint for schema synchronization. Prisma migration history, partial indexes, triggers, and hand-written SQL may not all be represented by schema diff. The API starts a schema guard for the one-live-run partial index because migration diff does not prove it exists.

## Key Decisions

- Share one canonical Prisma/RBAC package between Next and Express.
- Authenticate dashboard API traffic with the shared database session before considering bearer credentials.
- Resolve tenancy and permissions server-side from the authenticated principal.
- Store large bodies in object storage while keeping ownership/version/hash metadata in PostgreSQL.
- Audit mutations with redacted metadata and supplement schema migration with runtime guards for invisible constraints.

## Constraints

- Next and Express have separate pools and caches even inside one pod.
- Multiple auth models are intentional; consolidating them without caller analysis can break desktop, pods, Apps, or agents.
- Organization auto-join and personal-org creation affect authorization and billing state.
- PgBouncer transaction pooling changes assumptions around advisory locks and prepared statements.
- Object-storage cleanup is not automatically transactional with database mutation.
