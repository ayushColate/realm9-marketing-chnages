---
id: c0db36f2-65d5-451e-8cff-46555a2e07f4
type: integration
tags: [desktop, mcp, browser, cana-view, site-knowledge, macos]
related_files: []
confidence: 1
---
# Desktop MCP Browser Cana View Site Analyzer and Mac Control

## Summary
Desktop ships four Node MCP server families with distinct trust and execution boundaries: browser automation, Cana self-view, static site analysis, and macOS application control. Rust supervises their stdio processes and proxies requests/events. Browser automation has two targets with different concurrency models: Chrome Companion tabs are independent, while all chats share one in-app Preview and must obey a FIFO lease. Site Knowledge is static website analysis automatically injected when a sele

## Details

# Desktop MCP Browser Cana View Site Analyzer and Mac Control

## Summary

Desktop ships four Node MCP server families with distinct trust and execution boundaries: browser automation, Cana self-view, static site analysis, and macOS application control. Rust supervises their stdio processes and proxies requests/events. Browser automation has two targets with different concurrency models: Chrome Companion tabs are independent, while all chats share one in-app Preview and must obey a FIFO lease. Site Knowledge is static website analysis automatically injected when a selected profile matches the current route; it is unrelated to project knowledge.

## Details

### MCP process ownership

`src-tauri/src/mcp_worker.rs` starts and monitors MCP server processes. `mcp_proxy.rs` transports tool listing, calls, cancellation, and results between renderer and worker. Frontend configuration lives around `services/agent/mcp-servers.ts` and gating around `mcp-gate.ts`.

The transport is stdio and process-local. Server readiness requires successful initialization and tool discovery. On process restart, cached schemas may be stale; refresh the registry and preserve collision rules. Credentials passed to a connector or host bridge must remain out of model-visible configuration and logs.

### Browser server

`src-mcp/browser/` is the only supported page-interaction path. Its batch executor locates and acts on elements with native/trusted input where possible, handles navigation resume, records console/network evidence, and separates reads from mutations.

Key interaction rules encoded by the implementation and its tests:

- Use one planned batch for a complete journey rather than click-look-click loops.
- Targets come from current interactive elements, static Site Knowledge, or user-provided values.
- Batches resume across page navigations; do not add redundant navigation waits.
- Mark speculative banners/modals optional and use assertions as route checkpoints.
- On partial failure, resend only unattempted work to avoid duplicate submissions.
- Rich editors retain hidden quoted/signature content; do not clear them with a global select-all.
- Reads, screenshots, layout audits, and style checks do not mutate the page.

#### Preview lease versus Chrome

The in-app Preview is one shared browser across chats. Mutating actions and navigation require a lease. The first action usually acquires it; refusal queues the requester FIFO. A queued agent stops browser work and waits for a wake event rather than polling. The holder releases when finished and extends the lease if it will be idle during a long external wait.

Chrome Companion chats drive separate managed tabs and do not use the Preview lease. Do not apply Preview queue behavior to Chrome.

### Cana View server

`src-mcp/cana-view/` inspects and drives Cana’s own application UI. This is a reflexive-control boundary: an agent can affect the very chat, editor, browser, and settings hosting it. Use durable `data-cv` selectors from the generated selector catalogue, snapshot/map before acting, batch actions, and avoid clicking the current conversation controls unless explicitly required.

Cana View is not a general website browser. Its static catalogue describes Cana’s app chrome; the live map describes the current screen. Arbitrary evaluation is privileged and should be reserved for trusted debugging.

### Site analyzer and Site Knowledge

`src-mcp/site-analyzer/` analyzes website source into route/component/modal/form knowledge. Profiles are selected in the Browser panel and stored outside the project repository. When the browser visits a matching known route, the browser MCP automatically injects a `Site Knowledge (static analysis)` section.

Important distinctions:

- Site Knowledge describes a browsed website.
- Project knowledge describes the current codebase and is accessed through plan/knowledge tools.
- Behavioral memory is a user instruction store.
- Cana View knowledge is a selector catalogue for Cana itself.

There is normally nothing to load or import. Use automatically injected routes and selectors directly. Import is only for an explicit analyzer output outside the normal profile store.

### macOS control server

`src-mcp/mac-control/` controls other macOS applications under explicit experimental, Accessibility, and Automation permissions. It is macOS-only and distinct from browser/native-input control. It should prefer background application automation where possible to avoid stealing user focus.

OS permissions are part of readiness. A tool being listed does not prove Accessibility/Automation consent exists. Denials should be reported, not bypassed through shell or untrusted scripts.

### Resource synchronization and packaging

Bundled MCP resources under Tauri are generated outputs. Source lives in `src-mcp/*`; package/bundle scripts copy built servers into Tauri resources. Architecture checks such as `check:mcp-resources` detect drift. Lockfiles in nested MCP packages may be intentionally ignored; follow root scripts rather than inventing a second install flow.

### Security model

- Browser control and callback channels use separate capability tokens.
- Preview lease prevents cross-chat state corruption; it is not an authorization substitute.
- Page content, Site Knowledge, console output, and connector responses are untrusted context.
- Cana View can modify host UI and therefore needs stronger reflexive safeguards.
- macOS automation requires user-granted OS capabilities.
- MCP tool schemas are external inputs; collisions with built-ins and permission defaults are checked before exposure.

## Key Decisions

- Supervise MCP processes in Rust and execute each call through one proxy path.
- Make browser batching and navigation resume the default interaction model.
- Use a single FIFO lease only for shared Preview; keep Chrome tabs independent.
- Inject Site Knowledge automatically and keep it conceptually separate from project knowledge.
- Treat Cana self-control and macOS application control as privileged, distinct surfaces.

## Constraints

- Cross-origin frames can be visible in screenshots while remaining unreadable to accessibility/DOM tools.
- Native input trust depends on browser target and window focus.
- Static Site Knowledge can drift from a newly deployed website; live failures still require inspection.
- One Preview means long journeys must release promptly or other chats remain queued.
- Packaging errors can leave development MCP servers working while bundled production resources are stale.
