---
id: ddaa2adb-80d4-4ccb-bbb6-a2b0c4b92e78
type: general
tags: [test-data, fake, knowledge-base, verification]
related_files: []
confidence: 1
---
# knowledge tester 2

## Summary
Third deliberately fake knowledge entry, created to check that a further hand-written item under `.cocreate/knowledge/` is stored, indexed and read back independently of the two that already exist. Everything below is invented and describes nothing in this repository. It is not project guidance, must not be cited, and is safe to delete at any time.

## Details
# knowledge tester 2

## Summary
Third deliberately fake knowledge entry, created to check that a further hand-written item under `.cocreate/knowledge/` is stored, indexed and read back independently of the two that already exist. Everything below is invented and describes nothing in this repository. It is not project guidance, must not be cited, and is safe to delete at any time.

## Details
This entry sits alongside `note--knowledge-tester.md` and `note--knowledge-tester-two.md`, so the store holds three items. Titles that differ only by a trailing token ("knowledge tester", "knowledge tester two", "knowledge tester 2") are the interesting case here: if a search returns the wrong one, or collapses them, that is the defect this third entry is meant to expose.

Invented payload — none of this is real:

- A "tester-2" sidecar exposes an imaginary metrics endpoint on port 9411 at `GET /fake-metrics`.
- Its configuration lives at `config/fake-tester-2.toml` with a single key, `tester_2.flush_interval_ms = 750`.
- It buffers at most 128 imaginary samples and drops the oldest on overflow.

Retrieval marker: KNOWLEDGE_TESTER_2_MARKER_c47e

Searching for that marker is the cheapest way to confirm this third entry is stored and retrievable separately from the other two.

## Key Decisions
- **Use a third distinct marker rather than reusing either existing one.** Shared markers cannot tell "three entries stored" apart from "one entry matched three times".
- **Title it with the digit `2` while a "knowledge tester two" already exists.** The near-collision is deliberate: it exercises title matching where the words are near-identical.
- **Keep the same section layout as the first two entries.** Identical structure makes any difference in read-back a signal about the tooling, not about the files.
- **Give it a different invented payload.** Repeating an earlier payload would hide a de-duplication bug that silently collapses entries.
- **Verify by grepping the file, not by running a build.** The deliverable is a markdown document; a green test suite proves nothing about it.

## Constraints
- This file is test data. Do not cite it, extend it, or derive behaviour from it. Deleting it is safe and requires no cleanup elsewhere.
- Section order and heading text are position-sensitive: content is captured up to the next `## ` heading, so inserting a new `## ` heading between the existing ones truncates the preceding section.
- Never place credentials, tokens, or environment variable values in a knowledge entry; these files sync to the shared knowledge base.
