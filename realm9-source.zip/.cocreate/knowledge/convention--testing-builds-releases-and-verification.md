---
id: f27b1fe2-e2c0-44bc-84c4-92a216b6633c
type: convention
tags: [testing, builds, ci, release, verification, desktop, web]
related_files: []
confidence: 1
---
# Testing Builds Releases and Verification

## Summary
Cana’s desktop and web repositories have substantial TypeScript/Python/Rust and integration test surfaces, but current GitLab pipelines focus on image/release/deploy work and do not run the main unit-test suites. Local verification is therefore mandatory before relying on a change. Select the narrowest relevant test first, then run the owning package’s full check/build. Cross-repository contracts require checks on both the source and consumer. The enterprise repository has no application test ha

## Details

# Testing Builds Releases and Verification

## Summary

Cana’s desktop and web repositories have substantial TypeScript/Python/Rust and integration test surfaces, but current GitLab pipelines focus on image/release/deploy work and do not run the main unit-test suites. Local verification is therefore mandatory before relying on a change. Select the narrowest relevant test first, then run the owning package’s full check/build. Cross-repository contracts require checks on both the source and consumer. The enterprise repository has no application test harness; validate rendered manifests and deployed state.

## Details

### Desktop commands and toolchain

The desktop root uses npm. Relevant commands from `package.json` include:

- `npm test`: Vitest for `src/**/*.test.ts`, `src/**/*.test.tsx`, and `src-mcp/**/*.test.js` as configured in `vitest.config.ts`.
- `npm run build`: TypeScript compile plus Vite production build.
- `npm run tauri:dev` and `npm run tauri:build`: native development/package flows.
- `npm run check:architecture`: test plus architecture-boundary enforcement.
- `npm run check:mcp-resources`: verifies generated MCP bundle parity.
- `npm run check:no-console` and `npm run check:preview-lease`: targeted static/runtime contracts.
- `npm run gen:cana-knowledge`: regenerates Cana View selector knowledge where relevant.

Python uses root `pyproject.toml`, Python 3.11–3.12, and uv through `scripts/uv-sync.sh`; the environment lives in `src-agent/.venv`. `scripts/cana-agent.sh` exposes scoped/all/binary/live agent test modes. Do not use the old ordinary pip-install instruction from stale docs as the canonical setup path.

Rust tests live under Tauri modules and may use alternate target directories for expensive native builds. Process supervision, platform behavior, and packaged sidecars require native tests beyond frontend Vitest.

### Desktop verification by change class

- Frontend component/store/helper: scoped Vitest, then full `npm test`, then `npm run build` when TypeScript/bundle behavior changed.
- AppLayout/AiPanel/lifecycle: scoped race/interaction tests plus architecture and full frontend tests.
- Python agent/context/tool policy: scoped Python module test, full agent test mode, and protocol/frontend tests if envelopes changed.
- Rust commands/processes: targeted Cargo test plus Tauri build/package check on supported platforms.
- Browser/MCP: MCP unit tests, preview lease/resource checks, and a real browser journey where behavior is interactive.
- LLM translation: web canonical translation tests first, sync vendored desktop source, then desktop proxy build/tests.
- UI work: serve/open, run layout audit at mobile/tablet/desktop widths, inspect computed styles, and visually review light/dark app surfaces.

Live tests require explicit opt-in and credentials; never treat their absence as permission to use production keys.

### Web commands and package boundaries

The root uses pnpm at the pinned version and Turbo:

- `pnpm build`, `pnpm lint`, and `pnpm test` orchestrate workspace tasks.
- Database commands delegate to `packages/db` for generate, push, migrate, seed, and studio.
- API `pnpm test` runs Vitest over source and test directories; translation unit/integration and session concurrency have scoped tasks.
- Policy-safe tests have a dedicated configuration that blanks database, Redis, and provider inputs.
- Web has a config but no local Vitest dependency; run it through the API workspace’s Vitest binary as documented by `web/vitest.config.ts`.
- `packages/sdk-js` has its own build/test plus `verify:agent-boundary` and `verify:ui-package` before publish.
- `packages/embed-js` has a custom build; verify the served Next route and Docker copy contract.

For Prisma changes, generate the client, test domain helpers/routes, inspect SQL/migration effects, and exercise schema guards. `db push` success is not a substitute for reviewed migration safety.

### Web verification by change class

- Express route: scoped route test, API suite, type/build, auth/mount-order review, and enterprise ingress ownership.
- Next route/middleware: web test via the documented binary, Next build, session/CORS/CSP checks, and ingress path.
- Shared DB/RBAC/export: package build/tests, API and web consumers, Prisma generation, and runtime export-map build.
- Hosted Apps agent runtime: focused run-loop/store/lease/evidence/recovery tests plus API route tests.
- Translation/provider: parser/serializer/stream/upstream tests, incident replay, and desktop vendoring if shared output changes.
- SDK publish: test both ESM/CJS/browser artifacts and export/catalog boundary checks.
- Mobile: native Capacitor/iOS/Android flow plus hosted middleware/auth behavior; it is outside Turbo.

### Enterprise validation

There is no package manager or unit suite. Use:

- Helm lint/template with the intended values and chart dependencies.
- YAML/schema/policy checks for rendered resources.
- Diff the exact component-version keys changed by CI.
- ArgoCD sync/hook status.
- Prisma Job logs and schema guard readiness.
- Deployment rollout, liveness/readiness, both Services, and ingress probes.
- PostgreSQL/Redis health and resource pressure.
- Secret-reference existence without printing values.

A render proves syntax, not production health. A rollout status proves pods became ready, not that every routed prefix reaches the correct process.

### Desktop release flow

The desktop release pipeline is a manual main-branch action controlled by a publish flag and bump mode. Container/deploy jobs are gated out of the release path so a desktop publish cannot simultaneously redeploy remote production services.

`src-tauri/tauri.conf.json` is the version authority. The bump script updates the root package manifest/lock, Tauri config, and Cargo manifest/lock atomically. Platform builds produce signed Windows/macOS artifacts and updater metadata; publishing and verification are separate pipeline stages. CI uses cloud federation and retrieves signing material at runtime where configured.

Validate:

- All version files agree.
- Updater endpoints/manifests and signatures match artifacts.
- Windows bootstrap/updater contract and macOS signing/notarization status.
- Packaged agent, proxy, MCP, and editor resources exist and start.
- A real N-to-N+1 update on supported platforms before declaring rollout complete.

### CI gap

At the verified snapshot, neither main GitLab pipeline invokes the comprehensive Vitest/Python suites. Test-plan check jobs validate documentation synchronization and are advisory, not application correctness. Dependency scanning is useful but not a functional test. Until CI changes, reviewers must require explicit local command evidence in merge requests.

### Evidence discipline

Run verification after the final edit because later mutations invalidate earlier evidence. Record command, scope, exit code, and relevant result. Do not report a background job as passed while still running. For docs-only work, use a structural/content validator tailored to the docs instead of unrelated application builds.

## Key Decisions

- Use each owning package’s real package manager and test harness.
- Start scoped, then run full build/test for the affected repository and cross-repo consumers.
- Treat interactive UI/browser, native packaging, and deployment health as separate verification layers.
- Keep release version updates atomic and Tauri configuration authoritative.
- Compensate for the current CI unit-test gap with explicit local evidence.

## Constraints

- macOS cannot prove Windows behavior; add deterministic tests and run the Windows release path before rollout.
- Live provider tests need explicit credentials and may incur cost.
- Full desktop native builds and broad web suites are expensive, so targeted iteration should precede them.
- Helm rendering cannot prove external secrets, DNS, provider APIs, or runtime data migrations.
- Test counts and version numbers drift quickly; rely on current configs rather than snapshots.
