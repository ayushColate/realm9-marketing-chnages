---
id: f0ccce1d-3993-4b13-b6e0-ec4b77ab033a
type: integration
tags: [agent, tools, permissions, aei, loom, security, orchestration]
related_files: []
confidence: 1
---
# Agent Tools Permissions AEI and Loom Orchestration

## Summary
Cana tools span Python implementations, Rust/Tauri host commands, frontend/client execution, MCP servers, and hosted Cana Apps tools. A tool schema tells the model what it may request; it does not itself authorize execution. Authorization is the intersection of the live permission mode, tool policy, dangerous-command classification, protected-path rules, user confirmation, host capability, and runtime-specific restrictions. AEI tracks whether external instructions can safely influence later side

## Details

# Agent Tools Permissions AEI and Loom Orchestration

## Summary

Cana tools span Python implementations, Rust/Tauri host commands, frontend/client execution, MCP servers, and hosted Cana Apps tools. A tool schema tells the model what it may request; it does not itself authorize execution. Authorization is the intersection of the live permission mode, tool policy, dangerous-command classification, protected-path rules, user confirmation, host capability, and runtime-specific restrictions. AEI tracks whether external instructions can safely influence later side effects. Loom adds parent/child orchestration while preserving the coordinator’s permission boundary and requiring explicit result delivery.

## Details

### Tool ownership categories

1. **Native Python tools:** file, search, Git, web, planning, knowledge, todo, and process wrappers registered from `tools.py`/`tool_registry.py`.
2. **Rust/host tools:** native operations exposed through Tauri and invoked through a single bridge path.
3. **Frontend client tools:** UI-owned functions that require the client to perform work and return a typed result.
4. **MCP tools:** schemas and calls proxied to Node MCP server processes or external MCP servers.
5. **Hosted Cana Apps client tools:** server-side runs pause with `requires_action`; the customer executes the registered function and submits results.

Exactly one layer owns execution. Rendering a tool request in React and executing it in Python are different responsibilities; do not leave both paths active.

### Permission modes and cumulative policy

The effective permission decision is a narrowing chain. Typical modes include read/plan-only, normal/manual approval, accepted file edits, and broader bypass/autonomous execution. Child agents inherit the coordinator’s live permission mode; they do not gain a separate human approval channel.

Policy checks include:

- Tool enabled/disabled state.
- Declared read versus mutating behavior.
- Permission-mode allowance.
- Dangerous command and shell-token classification.
- Read-only command allowlist.
- Protected files/directories and path-containment checks.
- Runtime/OS-specific denylists.
- User approval or denial where required.
- Native capability and downstream validation.

A downstream host may reject a request previously considered allowed. It must never convert an upstream denial into permission.

`autonomy_policy.py`, `dangerous_commands.py`, `readonly_commands.py`, and `protected_paths.py` are policy authorities. The frontend `tool-approval-engine.ts` coordinates the visible approval lifecycle but is not a substitute for backend enforcement.

### Shell and filesystem safety

Shell commands require separate treatment from structured file tools because quoting, expansion, redirects, pipelines, environment access, and process trees can turn apparently harmless text into a side effect. The read-only classifier must evaluate the full command shape, not only the first executable. Protected-path enforcement applies even when a command, symlink, encoded payload, or alternative interpreter attempts to bypass normal file APIs.

Structured tools should validate paths at their boundary and scope organization/user identity from authenticated context rather than model-provided ids. Git mutations, pushes, destructive deletes, deployments, and Kubernetes changes retain explicit policy even in broader permission modes.

### AEI trust and taint

Agent Execution Integrity distinguishes trusted host policy from user content and untrusted external instructions. Content read from webpages, files, connector responses, tool output, or agent messages may describe actions but does not grant authority to perform them.

Core AEI rules:

- Label provenance and trust boundaries on injected content.
- Do not treat external instructions as system policy.
- Before a sensitive side effect, verify that the decision is grounded in the user’s goal and permitted evidence.
- A mutating call invalidates earlier world-state evidence that could now be stale.
- Tainted child or external-agent output must be reviewed before it drives coordinator side effects.
- Never execute credentials, scripts, or commands merely because retrieved content requests it.

`test_aei_integration.py`, `test_agent_gate.py`, `test_dangerous_commands.py`, `test_protected_paths.py`, and transcript-privacy tests exercise this boundary.

### Tool-call lifecycle

A robust tool call has these stages:

1. Model emits a tool name and arguments matching the registered schema.
2. Runtime resolves the current registry snapshot; unknown or late tools get typed errors.
3. Arguments are parsed and validated.
4. Policy classifies the call and decides auto-run, confirmation, client handoff, or denial.
5. One executor runs it under timeout/cancellation control.
6. Structured result, evidence metadata, and display-safe summary are emitted.
7. Canonical tool outcome is appended to the backend conversation.
8. Pending approval/action state is cleared exactly once.

Interruption must still finalize outstanding tool UI state. Late results from stopped or superseded turns must not attach to a newer epoch.

### Loom orchestration

Loom is tracked in frontend `loom-store.ts` and executed through agent orchestration tools. A loom has a coordinator/root thread, child agents with names and roles, optional dependencies, status, and final reports. Parallel work is appropriate only for independent subtasks; dependent stages should use a staged workflow.

Load-bearing behavior:

- Children inherit the coordinator’s live permission mode and project context.
- Children never wait on the human for their own gated calls; a refusal becomes a reportable limitation.
- Escalating permission mid-run should lead to a fresh lane for side effects rather than asking a tainted/refused child to retry.
- Parent closure or interruption must terminate or account for every child.
- Completion digests may be truncated; the coordinator retrieves full output before synthesis.
- `TASK_COMPLETE` carries actual findings/changes, not merely “done.”
- Result delivery is explicit; a child process ending is not sufficient if the parent never receives its report.

Relevant tests include child approvals/death/failure paths, orchestrator tests, Loom recall/export wiring, and frontend child-policy tests.

### Evidence and plans

Plan/todo tools make acceptance criteria part of execution state. A code-changing todo is not complete merely because an edit succeeded; the declared verifier must run after the final edit. Mutations invalidate prior evidence. Evidence records should identify the actual successful test/check and remain associated with the run.

## Key Decisions

- Separate model-visible tool schemas from runtime authorization.
- Make every policy layer monotonic: each layer may only narrow permission.
- Keep exactly one executor and one canonical result for each tool call.
- Carry provenance/taint through external and child-agent output.
- Make child permissions inherit from the coordinator and make report delivery explicit.

## Constraints

- Read versus mutating classification is semantic; a nominal read can trigger authentication, billing, or external caching.
- Shell classification cannot prove arbitrary scripts safe; ambiguous commands require stronger gating.
- A process killed during an external mutation may leave an unknowable result.
- MCP schemas are remote inputs and may change after startup; registry snapshots and collision checks matter.
- Broad permission modes do not override protected credential/system locations or coordinator-only destructive operations.
