---
id: 21afb877-4cef-41e7-95c9-79c13325062a
type: implementation
tags: []
related_files: []
confidence: 1
---
# Realm9 — IaC / FinOps / Compliance Platform

## Summary
Git-backed Terraform automation, env management, cost optimization, compliance scanning; ARM64 pods, external RDS Postgres, multi-source ArgoCD (ns realm9-prod).

## Details
# Realm9 — IaC / FinOps / Compliance Platform

## Summary
Git-backed Terraform automation, env management, cost optimization, compliance scanning; ARM64 pods, external RDS Postgres, multi-source ArgoCD (ns realm9-prod).

## Details
# Realm9

> Product knowledge for troubleshooting. Capabilities were extracted from source once;
> **do not go looking for the app code** — for deploy/config detail use the chart sources
> below and the live cluster. **`git pull` the values repo before relying on it.** Live-cluster
> facts verified 2026-06-18.

## Summary
Realm9 (realm9.app) is an **Infrastructure-as-Code + environment-management + FinOps +
compliance platform**: Git-backed Terraform automation across AWS / Azure / on-prem
(Proxmox/vSphere), environment lifecycle & booking, cloud cost optimization, policy/compliance
scanning (Checkov/Trivy/TruffleHog/CIS), drift detection, an AI assistant (OpenAI + MCP), and
semantic search — in one Next.js control plane. Sibling to the other Realm9-brand products
(Origin9/CoCreate); it has an optional **RO9 (Origin9) observability** integration, which is
**disabled in prod**. Don't over-assume the product hierarchy — describe what's deployed.

## Where it runs
- **Cluster:** US prod — `colate-eks-cluster-prod` (account `703850320248`, `us-east-1`).
  Pods run on **ARM64 Graviton** nodes (`appgroup=default-arm`, `arch=arm64`, with the matching
  `appgroup=default-arm:NoExecute` toleration) — images must be arm64.
- **Namespaces:** `realm9-prod` (prod app + Redis), `realm9-stg` (staging), `realm9-system`,
  `realm9-test`. Terraform runs execute as **ephemeral K8s Jobs in the shared `terraform-runs`
  namespace** (only old debug/test Jobs present at last check = no recent runs; empty-ish is
  normal). `license-server` ns exists but is **empty** — prod licensing is CLOUD mode via
  keygen.sh, so that ns is likely unused by Realm9 prod (confirm before assuming otherwise).
- **Public:** `realm9.app` (ingress nginx + cert-manager `letsencrypt-prod-dns01`, CORS pinned
  to `https://realm9.app`, rate-limited 100 rps / 50 conns).

## How it's deployed (ArgoCD, multi-source)
The `realm9-helm` ArgoCD Application (ns `realm9-prod`, `automated` sync with **prune +
selfHeal + ServerSideApply**) pulls from two sources:
1. **Chart (in ECR):** `oci://public.ecr.aws/realm9/helm/realm9`, chart `realm9`, **rev `1.0.34`**.
   The chart *templates* live here — pull with `helm pull oci://public.ecr.aws/realm9/helm/realm9 --version 1.0.34` if you need them; they are not in any local repo.
2. **Values + the Application manifest (git):** `gitlab.com/colate/argocd/platform-helm-charts`,
   cloned locally at **`/Users/prasad/Apps/Repository/claude-cleanup/platform-helm-charts/realm9`**
   (`application.yaml` + `values.yaml`). **`git pull` this before relying on it.**

- **App image:** `registry.colate.io/realm9/realm9-core`, **`componentVersion` 1.426.0** (verify
  after pulling). The GitLab pipeline builds → pushes the image → bumps `componentVersion` in
  `values.yaml` → ArgoCD auto-syncs. **selfHeal + prune are ON, so live hand-edits get reverted
  fast** — fixes go through the values repo / pipeline (and are owner-only).
- ArgoCD apps at last check: `realm9-helm` Synced/Healthy, `realm9-rds` Synced/Healthy (prod);
  `realm9-stg-helm` **OutOfSync**/Healthy, `realm9-rds-stg` Synced/Healthy (staging). The staging
  OutOfSync should self-heal; values were just changed.

## Runtime workloads — ns `realm9-prod` (verified on-cluster)
| Workload | Kind | Replicas | Role |
|---|---|---|---|
| `realm9-helm` | Deployment | 2 (**HPA 2→10**, CPU 70% / mem 80%) | The Realm9 app — Next.js UI/API (:3000), plus MCP (:3001) and agent (:3003) servers. The monolith. |
| `realm9-helm-redis-stack-master` | StatefulSet | 1 | Redis Stack master — cache, locks, BullMQ, pub/sub, **and the vector DB for semantic search** (`vectorDb.provider=redis`, index `realm9-vectors`). |
| `realm9-helm-redis-stack-replicas` | StatefulSet | 2 | Redis replicas. |

**There is no Postgres pod here.** The in-chart Zalando Postgres is **disabled**
(`postgresqlEnabled: false`); the database is **external AWS RDS**.

## Data & AWS resources
- **Database — external AWS RDS (Postgres):** host
  `colate-eks-cluster-prod-postgres.…us-east-1.rds.amazonaws.com`, db `realm9db`, port 5432, SSL.
  Managed alongside the **`realm9-rds` ArgoCD app**. **DB problems are NOT in-cluster** — check
  the RDS instance, the `realm9-rds` app, and the connection secret, not a pod.
- **Redis:** in-cluster Redis Stack (above), ARM64, password-auth.
- **Terraform state:** S3 bucket `realm9-terraform-state` + DynamoDB lock table
  `terraform-state-locks` (us-east-1).
- **S3 buckets:** `realm9-data` (app), `ro9-observability` (observability), `realm9-terraform-state`,
  `realm9-templates-prod-use1` (VM/compute templates). **SES** sends from `noreply@realm9.app`.
- **AWS access (IRSA):** role `realm9-aws-permissions-iam-role` (account 703850320248, us-east-1).
- **Utility images** mirrored from Docker Hub to `registry.colate.io/.../realm9/mirrors/*` to dodge
  rate limits (kubectl, redis, postgres). Pull secret `gitlab-registry-pull`.

## Core capabilities
- **Terraform automation** — plan/apply/destroy/refresh, Git-backed workflows; runs as K8s Jobs
  (init: git-clone + secrets inject; policy-scan sidecars). Auto-plan batching; terraform-ls LSP.
- **Multi-cloud** — AWS + Azure + on-prem (Proxmox/vSphere); IAM/RBAC role validation; VPN
  provision/destroy via TF Jobs (on-prem `vpcId` configured).
- **FinOps** — AWS + Azure cost ingestion (line-item), forecasting, budgets, anomaly detection,
  right-sizing recommendations.
- **Compliance/policy** — Checkov, TruffleHog, Trivy scanning; **CIS scanner** as a K8s Job
  (image `…/realm9/cis-scanner:dev` — note: unpinned `:dev` tag in prod); audit logging.
- **Environment management** — provisioning, lifecycle, dependencies, booking/reservations with
  approvals, custom field templates, ServiceNow CMDB integration.
- **AI & search** — Monaco-based TF editor, OpenAI assistant + `@openai/agents`, **MCP server**;
  semantic search (Redis vectors; Weaviate/Qdrant optional, disabled).
- **Identity/governance** — SSO/SAML/OIDC, SCIM provisioning, RBAC permission matrix, drift
  detection (cron + webhook-driven). GitHub App + GitLab webhooks (HMAC-verified).

## Architecture & dependencies
- **App:** monolithic Next.js 14 / React 18 + Fastify (WebSocket log streaming); BullMQ +
  croner for background jobs/cron (`enableScheduler=true`). Prisma over **external RDS Postgres**;
  **Redis Stack** for cache/locks/queues/vectors.
- **Terraform engine:** runs as K8s **Jobs in `terraform-runs`**; state in S3 + DynamoDB locks.
- **Licensing:** CLOUD mode via **keygen.sh** (account id in values); not the local `license-server` ns.
- **RO9/Origin9 observability:** integration present but **`observability.enabled=false` in prod**
  (would talk to `ro9-query`:4002 / `ro9-ingest`:4001 + OTLP).

## Config & secrets (where they live — never print values)
- Config + **secrets are in the chart `values.yaml`** in the values repo and rendered into a
  cluster Secret/ConfigMap. The file holds the **RDS password, OpenAI API key, and the app
  `encryptionKey`** in plaintext (same committed-secrets exposure flagged for the other products).
- The Argo app sets `ignoreDifferences` on `Secret` `/data` & `/stringData`, so secret drift
  isn't shown by ArgoCD.
- Per the absolute rule in `CLAUDE.md`, never output any secret value — give its location only.

## Operational notes & known quirks
- **ArgoCD owns desired state with selfHeal + prune** — hand-edits are reverted quickly; real
  fixes go through the values repo + pipeline.
- **Database is external AWS RDS** — for DB symptoms, look at RDS / the `realm9-rds` app, not pods.
- **ARM64-only** — a non-arm64 image or missing `default-arm` capacity will leave pods Pending.
- **Terraform runs are ephemeral Jobs in `terraform-runs`**; if provisioning fails look for failed
  Jobs / ImagePullBackOff there and for **S3/DynamoDB state-lock contention**.
- **Leads from the codebase (verify, don't assume):** TF runs in `PENDING_APPROVAL` have **no TTL**
  and can hang indefinitely; TF log tables (`TerraformRunLog`, etc.) are **unbounded** (DB growth);
  webhook replays lack idempotency (possible duplicate runs). Treat these as starting points, not
  confirmed causes.
- **CIS scanner uses an unpinned `:dev` image** in prod (per a values comment, pending a stg smoke
  test before pinning).
