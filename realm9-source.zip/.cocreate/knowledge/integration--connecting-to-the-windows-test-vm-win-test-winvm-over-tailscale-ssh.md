---
id: 58383ddf-d8d4-4fac-8f86-3031d0336a7e
type: integration
tags: [windows, testing, tailscale, ssh, infrastructure, cana-desktop]
related_files: [docs/windows-test-boxes.md]
confidence: 1
---
# Connecting to the Windows test VM (win-test-winvm) over Tailscale + SSH

## Summary
The Windows test box is reachable over Tailscale by SSH with the key already on this Mac — no AWS credentials, no password, nothing to ask the user for. Do NOT use the private IP shown on the dashboard (10.20.11.198); it is unroutable from here and both ping and SSH time out, which looks like "no access" but is just the wrong address. Use the tailnet name instead: `ssh Administrator@win-test-winvm.taila62b9f.ts.net`. Auth succeeds immediately; the repo is already checked out at C:\Users\Administ

## Details
# Connecting to the Windows test VM (win-test-winvm) over Tailscale + SSH

## Summary
The Windows test box is reachable over Tailscale by SSH with the key already on this Mac — no AWS credentials, no password, nothing to ask the user for. Do NOT use the private IP shown on the dashboard (10.20.11.198); it is unroutable from here and both ping and SSH time out, which looks like "no access" but is just the wrong address. Use the tailnet name instead: `ssh Administrator@win-test-winvm.taila62b9f.ts.net`. Auth succeeds immediately; the repo is already checked out at C:\Users\Administrator\cana with the full toolchain (Node 24, Rust MSVC, git, uv + src-agent/.venv) on PATH.

## Details
## The route that works

```bash
# find the box (names, not the dashboard's private IP)
/Applications/Tailscale.app/Contents/MacOS/Tailscale status

ssh Administrator@win-test-winvm.taila62b9f.ts.net "cmd.exe /c ver"
```

- Host: `win-test-winvm.taila62b9f.ts.net` = `100.105.186.75`, user `Administrator`
- SSH key on this Mac is ALREADY authorised — `BatchMode=yes` connects without a prompt
- Desktop repo: `C:\Users\Administrator\cana`; cana-web: `C:\Users\Administrator\cana-web`
- Full details (other boxes, RDP, firewall policy): `docs/windows-test-boxes.md` in the cana-desktop repo

## Dead ends — don't repeat these

- **The dashboard's Private IP `10.20.11.198` is not reachable from this Mac.** Ping and ssh both time out. The box has no public IP and its security group has zero ingress; Tailscale is the only path.
- **AWS CLI has no credentials configured** (`aws sts get-caller-identity` → NoCredentials) and `session-manager-plugin` is not installed, so the SSM break-glass channel is not available without setup.
- `~/.ssh` is sandbox-protected, so the ssh config cannot be read — but it does not need to be; the tailnet hostname plus `Administrator` is enough.
- `ssh-add -l` reports no agent; key auth still works via the on-disk key.

## Failure mode seen 2026-09-19: "paging file is too small"

SSH connects and authenticates, then EVERY shell dies before running anything:

```
Unable to load DLL 'secur32.dll': The paging file is too small for this operation to complete. (0x800705AF)
Exception of type 'System.OutOfMemoryException' was thrown.
Process is terminated due to StackOverflowException.
```

This is the VM being out of memory/paging space, NOT an access or credential problem — auth already succeeded by the time it appears. `cmd.exe /c`, `powershell.exe -NoProfile` and the default shell all fail identically, so trying another shell is wasted effort.

Fix: stop/start the instance from the team dashboard at `http://win-test-helper-1.taila62b9f.ts.net` (returns HTTP 200; it has Start/Stop buttons), then allow ~2 minutes for Windows to come up.

## Other boxes on the tailnet

`win-rdp-india` (100.127.244.34) and `cana-win-builder` (100.115.61.58) are usually **offline** — check `tailscale status` before assuming a box is broken. Boxes auto-stop after 60 idle minutes, so "refuses connections" almost always means "switched off", not "misconfigured".

## Key Decisions
Use the Tailscale hostname, never the dashboard's private IP. Treat "paging file is too small" / OutOfMemoryException as a VM-health problem to be fixed by stop/start from the dashboard, not as an auth or shell-selection problem.

## Constraints
Tailscale must be connected on this Mac. The VM auto-stops after 60 idle minutes. SSH works only for Administrator with the existing key; no password is stored anywhere in the repo.
