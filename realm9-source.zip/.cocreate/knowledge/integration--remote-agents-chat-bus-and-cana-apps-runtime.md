---
id: 01fc6ff4-3efa-4aaa-9d9b-00c0ed5247eb
type: integration
tags: [web, remote-agents, chat, bus, schedules, cana-apps]
related_files: []
confidence: 1
---
# Remote Agents Chat Bus and Cana Apps Runtime

## Summary
The hosted API coordinates several agent products rather than one universal runtime. Remote Claude Code, remote Cana agents, internal runtimes, chat tool loops, scheduled runs, Walkie-Talkie bus agents, and Cana Apps have different protocols and persistence. Common infrastructure includes signed session credentials, WebSocket bridges, PostgreSQL durable state, Redis election/coordination, S3 snapshots/attachments, and Kubernetes or Lambda execution. Names that sound similar are not interchangeab

## Details

# Remote Agents Chat Bus and Cana Apps Runtime

## Summary

The hosted API coordinates several agent products rather than one universal runtime. Remote Claude Code, remote Cana agents, internal runtimes, chat tool loops, scheduled runs, Walkie-Talkie bus agents, and Cana Apps have different protocols and persistence. Common infrastructure includes signed session credentials, WebSocket bridges, PostgreSQL durable state, Redis election/coordination, S3 snapshots/attachments, and Kubernetes or Lambda execution. Names that sound similar are not interchangeable; follow the route and service owner for the exact runtime.

## Details

### Runtime families

- **Remote Claude Code (RCC):** remote coding sessions using a dedicated bridge, pool/session services, and pod images built from desktop-owned runtime sources.
- **Remote Cana Agent (RCA):** Cana agent sessions whose API service provisions or connects to runtime pods, handles boot/resume/snapshot and preview access.
- **RCC internal:** separately configured internal runtime/bridge with its own deployment switch and trust boundary.
- **Hosted chat:** API-owned conversation, attachment/file injection, tool loop, model translation, context pruning, and sub-agent records.
- **Cana Apps agent runtime:** application-scoped threads and durable runs with server-owned history/context/evidence and optional client tool handoff.
- **Walkie-Talkie bus/boards:** channel-based human/agent communication and task coordination using agent identities/tokens plus user auth.
- **Scheduled agents/templates:** recurring or webhook-triggered creation of RCA/template work under internal/user/API-key authentication.

Do not infer behavior from old “remote agent” design documents. Follow current `api/src/index.ts` mounts and the relevant route/service pair.

### Session credentials and bridges

Remote runtime connections use signed short-lived session credentials scoped to session, audience, and purpose. WebSocket bridges attach to the Express HTTP server for RCC, RCC-internal, RCA, bus, and Deepgram. The server, not the browser, holds provider/transcription credentials where possible.

Session credential validation and user authorization are separate. A valid pod/session token proves runtime identity; it does not automatically authorize reading another user’s session. Bridge handlers must bind connection identity to durable session ownership and reject replay/expiry.

### RCA lifecycle

`routes/rca.ts` exposes session lifecycle while `services/rca-pool.ts` owns runtime allocation and connection. Depending on configuration, the API may use Kubernetes pods, a configured remote URL, or other runtime modes. Image identifiers come from enterprise configuration updated by desktop CI.

Resume and persistence involve:

- Database session metadata and status.
- Redis coordination/locks/cache where applicable.
- S3 snapshots or handoff archives.
- Git credential broker integration scoped to the repository.
- Preview authentication with single-use handshakes and host-only cookies.
- Expiry sweepers and cleanup.

Large handoff uploads route directly to Express in production because the previous Next proxy path corrupted request bodies. Preserve ingress ownership and integrity tests.

### RCC lifecycle

`services/rcc-pool.ts`, RCC routes, and `rcc-session-jwt.ts` manage remote code sessions and their bridges. Legacy direct proxy paths have been removed in favor of the current `/ws/rcc/:sessionId` bridge. Desktop frontend backend names and old documents may retain historical terminology; current service mounts are authority.

### Hosted chat

Hosted chat combines database sessions/messages with S3-backed attachments and chat files. Attachment extraction and inline injection are separate services; file versions and archive sweepers preserve lifecycle. `chat-tool-loop.ts` and translation services execute model/tool turns, while context tiers/pruning/window modules bound payloads.

Public share and preview endpoints mount before authenticated chat/file routers. Direct-to-Express chat prefixes require bearer-aware clients and matching enterprise ingress entries; remaining browser routes may go through Next for cookie-to-bearer proxying.

### Walkie-Talkie bus and boards

The bus supports user-authenticated dashboard calls and separately authenticated agents. Attachment download and boards use dual authentication. Zero-setup device join exposes an unauthenticated start/poll phase where the device code is the bearer capability, followed by authenticated human approval before an agent credential is minted.

Redis/WebSocket delivery is not the only state: PostgreSQL models persist channels, messages, memberships/grants, devices, attachments, audits, and board tasks/dependencies/events. Push delivery and reminder workers are additional consumers. Agent credentials are hashed with a server-side pepper; never log raw credentials.

### Schedules and webhook templates

Scheduled agents are created by users but fired by an internal cron worker. Internal requests carry a secret handshake and an acting user id; routes must validate both and then retain the user’s authorization boundary. Webhook templates can authenticate through owner API keys, user session/JWT for “run now,” or the internal cron path. These paths converge on the same template/run logic so they do not create an unaudited impersonation shortcut.

### Cana Apps configuration and access

A Cana App has model/configuration, instructions, appearance/messaging, access mode, allowed embed origins, connectors, client tools, rate/spend limits, hosted page, developer API state, and runtime mode. Dashboard server actions use browser sessions; desktop has a bearer-authenticated Apps API; embed/Developer API callers use App-specific credentials and visitor flows.

Public versus authenticated Apps is an explicit access decision. Authenticated Apps require an issuer/sign-in policy before publication. Embed origins are enforced both in application auth and hosted-page CSP/frame ancestors. Connector credentials are encrypted and write-only.

### Cana Apps proxy versus agent runtime

- **Proxy mode:** the customer executes the agent loop; Cana routes model/provider calls.
- **Agent mode:** Cana owns thread history, context, evidence, runs, and tool-call progression. Client tools pause a run with `requires_action`; the customer executes the function and submits results.

Agent mode is additive: the OpenAI-compatible proxy surface remains available. Switching a live runtime mode is operationally sensitive because in-flight runs may be cancelled when moving back.

### Durable runs, leases, and recovery

Apps run state is stored in database rows/events/tool calls/evidence/checkpoints. A partial unique index enforces one live run per thread; the API schema guard verifies it at boot. Run drivers use leases/epochs/heartbeats so one process owns progress. Redis elects expiry and recovery scanning, while database row conditions are the authoritative fence.

A run abandoned in `requires_action` must expire; otherwise it permanently blocks the thread. A process dying after queueing or while running is recovered by a scheduler using durable heartbeat/claim state. Webhook sinks and SSE/event subscribers consume the durable event stream rather than relying only on in-memory callbacks.

### Evidence and client tools

Client tool schemas are registered per App. Read/mutating metadata and AUTO/CONFIRM policy feed the evidence gate. A mutation invalidates earlier evidence that may have become stale. Client arguments must not include organization/user scope; the customer process derives scope from its authenticated caller.

## Key Decisions

- Keep runtime families and protocols explicit rather than forcing one generic session abstraction.
- Use short-lived signed runtime credentials plus independent user/resource authorization.
- Make durable database state and lease epochs authoritative; use Redis for coordination/election.
- Preserve direct Express routing for byte-sensitive uploads and bearer/WebSocket surfaces.
- In Apps agent mode, pause for client-owned tools and resume from a durable action result.

## Constraints

- Image versions cross repository boundaries and can drift from API expectations.
- WebSockets need graceful drain and reconnection without duplicating side effects.
- Kubernetes, Lambda, Redis, S3, Git providers, and PostgreSQL can fail independently.
- Public share/device/embed endpoints are intentionally reachable but must be capability-scoped and replay-resistant.
- A stale live-run row or missing recovery worker can wedge a thread until expiry/repair.
