---
id: b0a35828-085c-4c51-ba3f-22a8f2e2dad7
type: architecture
tags: [desktop, plan, documents, knowledge, memory, sync]
related_files: []
confidence: 1
---
# Desktop Plan Documents Knowledge and Behavioral Memory

## Summary
Cana has four distinct “remembered information” systems: Plan data/documents, structured project or organization knowledge, behavioral memory, and browser Site Knowledge. Plan and knowledge can synchronize with Cana Web, while behavioral memory remains a scoped desktop SQLite instruction store and Site Knowledge is generated static analysis for browser navigation. Agent working plans also share the `.cocreate/plans` parent but are directories, deliberately excluded from cloud-document upload.

## Details

# Desktop Plan Documents Knowledge and Behavioral Memory

## Summary

Cana has four distinct “remembered information” systems: Plan data/documents, structured project or organization knowledge, behavioral memory, and browser Site Knowledge. Plan and knowledge can synchronize with Cana Web, while behavioral memory remains a scoped desktop SQLite instruction store and Site Knowledge is generated static analysis for browser navigation. Agent working plans also share the `.cocreate/plans` parent but are directories, deliberately excluded from cloud-document upload.

## Details

### Plan projects, tasks, and documents

`src/stores/plan-store.ts` is the React/Zustand cache and selection layer. SQLite operations live in `services/db/plan-db.ts`; cloud behavior lives in `services/plan/cloud-sync-service.ts`. The store initializes projects, tasks, and documents together and uses single-flight guards so multiple boot paths do not duplicate initialization or repository project creation.

Plan project identity is repository-aware. Cloud synchronization deduplicates projects by normalized repository URL within an organization. Updates are generally last-write-wins by timestamps. Task and meeting deletion use archival semantics on the hosted side where defined, while documents use their own deletion/version behavior. Meeting synchronization sends transcript/analysis content, not recorder audio.

The `pendingSection` latch exists because the Plan page follows the lazy-mount pattern: a DOM event emitted before first mount can be lost. New navigation requests should use the store-backed request/consume mechanism when delivery must survive mounting races.

### Cloud documents and local replicas

`services/plan/plans-file-sync.ts` synchronizes hosted documents to flat Markdown files under `.cocreate/plans/`. Cloud list metadata includes version and content hash so unchanged bodies avoid repeated S3 reads and incidental access-time writes. A downloaded body is hash-verified before it becomes the local replica.

Local edits to an existing cloud replica are not silently overwritten: when the stored content hash differs, the sync writes a recovery copy under `.cocreate/plans/.conflicts/` before restoring cloud state. New flat Markdown files without a cloud id are uploaded as draft documents.

Agent execution plans have a different shape: `.cocreate/plans/<plan-slug>/PLAN.md` plus a `todos/` directory. The sync skips directories specifically so internal agent plans do not become user documents.

### Structured knowledge

The Python runtime writes Markdown knowledge beneath `.cocreate/knowledge/project/` or `.cocreate/knowledge/global/`. Its legacy formatter supports title/tags/scope timestamps, while the newer cloud sync understands richer frontmatter. The live cloud knowledge types are exactly `architecture`, `implementation`, `convention`, and `integration` as defined in `services/api/documents-api.ts`.

`services/plan/knowledge-file-sync.ts` is bidirectional with cloud-first behavior:

- Hosted project and organization knowledge is listed together.
- Organization-scoped items land in `global/`; project items remain project-local.
- Cloud items include an id in frontmatter and can be cleaned up locally after deletion.
- Local files must follow a `{type}--{name}.md` convention or declare a valid type.
- Locally created items pass an importance-curation judge; routine items remain local while important/critical items may upload.
- The sync records a content fingerprint and importance verdict to avoid re-judging unchanged files.
- A local `global/` file maps to organization scope, not “all Cana users.”

Cloud body storage and metadata are separate; knowledge metadata lives in the database while full content can be S3-backed. Never assume a list response contains the authoritative body.

### Behavioral memory

Behavioral memory is not a knowledge article. `services/memory/memory-repository.ts` stores user-confirmed instructions in the desktop `behavioral_memories` SQLite table. Records have system, workspace, or project scope plus optional conflict keys, source metadata, enabled state, and timestamps.

`effective-memory.ts` selects only enabled memories applicable to the current workspace/project. More specific scopes win conflicts: project over workspace over system; newer entries win within a scope. Entries are budgeted, escaped, and wrapped as user-confirmed behavioral instructions in the system prompt.

Use memory for durable “always/never/how to work” preferences. Do not store architecture, incident findings, transient tasks, secrets, or pasted external text as behavioral instructions. Contradictory memories should be replaced/deleted rather than left active together.

### Site Knowledge and Cana View knowledge

Site Knowledge belongs to browser profiles and describes a browsed website’s routes/forms/components. It is injected automatically by browser MCP. Cana View’s selector catalogue describes Cana’s own UI. Neither belongs in project knowledge files or the behavioral-memory table.

### Migration and path invariants

`.cocreate` is the current workspace root. Startup migration in `agent-session.ts` moves legacy `.claude` state when appropriate and starts Plan/knowledge sync for every backend, not only one agent type. Path helpers in `src/lib/workspace-paths.ts` should be used rather than hard-coded joins.

## Key Decisions

- Keep user-facing Plan records, agent working plans, structured knowledge, and behavioral instructions as separate data models.
- Make hosted cloud content authoritative for already-synced document/knowledge replicas while preserving local conflict copies.
- Restrict cloud knowledge to the four server-enforced types and use frontmatter/filename conventions.
- Resolve behavioral-memory conflicts by specificity and recency under a fixed prompt budget.
- Start file synchronization independently of the selected agent backend.

## Constraints

- `INDEX.md` and other nonconforming files are intentionally not uploaded as knowledge entries.
- Existing cloud-id files are primarily cloud-to-local; arbitrary local edits are not a general collaborative merge protocol.
- Organization-global knowledge may expose content to teammates, so secret scanning is required before upload.
- Workspace and project path normalization are identity-sensitive, especially across Windows-shaped paths.
- Legacy Python frontmatter parsing is deliberately simple; avoid complex YAML structures that the runtime cannot read.
