---
id: 9ced0eeb-e36e-4dab-aa5f-ba39d6d0ae1e
type: architecture
tags: [desktop, react, navigation, state, windows, frontend]
related_files: []
confidence: 1
---
# Desktop Frontend Shell State and Navigation

## Summary
The desktop frontend is a React 19 application hosted in Tauri windows. It does not use a URL router for primary navigation. `AppLayout` owns a string-valued application mode and keeps visited surfaces mounted, while a single AI tab manager remains alive across modes. Persistent application settings live mainly in `AppStateProvider`; fast or domain-specific UI state lives in Zustand stores. Window identity is load-bearing because primary, secondary, notification, and Buddy windows must not all r

## Details

# Desktop Frontend Shell State and Navigation

## Summary

The desktop frontend is a React 19 application hosted in Tauri windows. It does not use a URL router for primary navigation. `AppLayout` owns a string-valued application mode and keeps visited surfaces mounted, while a single AI tab manager remains alive across modes. Persistent application settings live mainly in `AppStateProvider`; fast or domain-specific UI state lives in Zustand stores. Window identity is load-bearing because primary, secondary, notification, and Buddy windows must not all run the same listeners or persistence writes.

## Details

### Boot and window kinds

`src/main.tsx` applies cached zoom before React mounts, then renders `App` under `React.StrictMode`. `src/App.tsx` selects one of three trees from the `window` query parameter:

- `notification`: only the meeting notification window.
- `buddy-chat`: theme, tooltip, error boundary, app-state provider, Buddy bridge, and Buddy panel.
- default/main: theme and error boundaries, `AuthGate`, app state, `AppLayout`, Buddy surfaces, plus global approval, context-menu, and toast hosts.

The plugin approval host intentionally remains outside the authentication gate so unhandled approvals fail closed. Theme names and storage key are duplicated for the main and Buddy trees; changes must keep both trees aligned.

### Navigation without a router

`src/components/layout/app-layout.tsx` holds `appMode`. `AppMode` is intentionally a string rather than a closed union because plugins may contribute pages. Stable internal ids include:

- `compose`: Vibe, the default mode.
- `docs`: Context/Plan surface.
- `editor`: Code surface.
- `browser`: Preview surface.
- `kubectl`: Cloud/Deploy surface.
- `ai-assistant`: full-page Settings.
- `applications` and dynamic plugin page ids.

User-facing labels may change; internal ids are compatibility contracts used by commands, stored preferences, tests, and events. Settings remembers the previous non-settings mode so closing or toggling returns to the prior surface.

`useVisited` implements “lazy mount, then keep mounted.” A visited mode stays in the DOM and is hidden when inactive. The editor may mount before first visit when a project is open to prewarm code-server, and it uses invisibility/pointer gating rather than `display:none` so the workbench receives real dimensions. Vibe can sit beneath the opaque AI layer for the same reason.

### Shared shell and event buses

`AppLayout` renders permanent hosts including the status bar, hidden terminal host, meeting detection, extension bridge, command/search dialogs, project dialogs, and mode-specific header portal targets. Mode pages portal their headers into stable shell slots.

Navigation and cross-component actions use both:

- Window-scoped Tauri events through `getCurrentWebviewWindow().listen(...)`.
- A large DOM custom-event bus for settings, folders, modes, plugins, MCP requests, editor navigation, meetings, recording, and cloud views.

Do not replace a window-scoped listener with a global Tauri listener: global listeners fire in every window and previously caused duplicate Preview opening and multi-window close behavior.

### Commands and keyboard routing

`services/commands/command-registry.ts`, `keybinding-service.ts`, and `core-commands.ts` form the command system. `CORE_KEYBINDINGS` is shared by runtime registration and the Settings reference table. Stable shortcuts cover files, search, editor views, settings, meetings, recording, zoom, tab close, and the five principal modes. Double-Shift opens global search outside the registry.

macOS has special caret and plain-field undo handling because native menu key equivalents and WebView key translation can otherwise steal or corrupt input. Preserve opt-out attributes and the last-editable-focus tracking when changing menu dispatch.

### State ownership

`contexts/app-state-context.tsx` persists broad application state through the Tauri store file. It owns AI settings, workspaces, editor session, UI preferences, skills, commands, MCP servers, meeting settings, Kubernetes settings, and migrations. Certain UI keys are window-local: cross-window updates must not adopt them, and secondary windows must not persist them. This prevents “last closed window wins.”

Zustand modules under `src/stores/` own narrower domains: auth, meetings, plans, chat tabs, Loom, Kubernetes, plugins, saved views, resource tabs, and UI latches. Use the established owner instead of adding a second store for the same lifecycle.

### Chat tabs and backend lifecycle

`AiPanelTabManager` mounts once and renders an `AiPanel` per chat tab. `ai-panel.tsx` is a major orchestration hotspot; prefer extracting tested helpers rather than expanding it casually.

`chat-tab-store.ts` makes the tab id the agent session id. Each tab carries backend/model route, document, permission, project directory, hierarchy, and Loom attachment metadata. Project adoption is atomic: flush outgoing persistence, tear down outgoing backends, restore or seed the incoming project, then adopt project path/tabs/active id together.

`chat-tab-persistence.ts` is deliberately hand-written rather than Zustand persistence because startup flags and per-window storage keys must be known before hydration. Structural tab changes persist synchronously; other metadata is debounced, with page-hide flushes. Project keys normalize path shape, including Windows-style paths even when tests run on another OS.

`services/agent/agent-session.ts` is the frontend’s backend switchboard. It starts file synchronization for every backend, performs legacy `.claude` to `.cocreate` migration, then routes to native, Claude, remote, or internal runtimes.

## Key Decisions

- Preserve stable mode ids and string extensibility for plugin pages.
- Mount expensive surfaces once and hide them rather than losing terminal/editor/browser state.
- Scope Tauri listeners to the current window unless multi-window fanout is explicitly intended.
- Keep persisted app settings, domain Zustand stores, and backend-owned conversation state separate.
- Treat project/tab adoption and backend teardown ordering as transactional.

## Constraints

- `AppLayout` and `AiPanel` are very large hotspots with many implicit lifecycle contracts; changes require scoped tests and architecture checks.
- Browser, editor, terminal, and meeting surfaces have native resources that outlive a React render.
- Secondary windows must not run primary-window update or plugin-update startup work.
- User-visible naming differs from internal ids; renaming labels does not authorize renaming persisted identifiers.
