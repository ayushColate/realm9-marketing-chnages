---
id: dbf5aae8-5eb0-40af-96f3-623c3ca89a00
type: convention
tags: [cana, workspace, index, architecture, operations]
related_files: []
confidence: 1
---
# Cana Workspace Knowledge Index

## Summary
This library is the source-grounded orientation map for the three-repository Cana workspace. It records implemented architecture, integration contracts, operational ownership, security boundaries, and documentation freshness. Code and current manifests are authoritative; each article states when a cited document is only a proposal, design, runbook, or stale reference.

The repositories are independent Git roots. `cana-desktop` owns the desktop client and agent/container runtimes, `cana-web` owns

## Details

# Cana Workspace Knowledge Index

## Summary

This library is the source-grounded orientation map for the three-repository Cana workspace. It records implemented architecture, integration contracts, operational ownership, security boundaries, and documentation freshness. Code and current manifests are authoritative; each article states when a cited document is only a proposal, design, runbook, or stale reference.

The repositories are independent Git roots. `cana-desktop` owns the desktop client and agent/container runtimes, `cana-web` owns the hosted product and shared data/runtime packages, and `cana-web-enterprise` owns ArgoCD/Helm desired state. The knowledge lives at the workspace root so updating it does not dirty any of those repositories.

## Details

### Task-to-article routing

| Task | Read first | Then read |
|---|---|---|
| Understand repository ownership or cross-repo changes | `architecture--cana-workspace-repository-map-and-ownership-boundaries.md` | `documentation--freshness-and-source-of-truth-rules.md` |
| Change desktop layout, navigation, windows, or state | `architecture--desktop-frontend-shell-state-and-navigation.md` | `testing--builds-releases-and-verification.md` |
| Add a Tauri command or native OS feature | `architecture--desktop-tauri-rust-process-and-os-bridge.md` | `security--credential-boundaries-rotation-and-known-risks.md` |
| Change agent turns, context, persistence, or compaction | `architecture--native-agent-runtime-turns-persistence-and-context.md` | `integration--agent-tools-permissions-aei-and-loom-orchestration.md` |
| Add or change agent tools or child-agent execution | `integration--agent-tools-permissions-aei-and-loom-orchestration.md` | `architecture--native-agent-runtime-turns-persistence-and-context.md` |
| Change model/provider routing | `integration--desktop-llm-routing-proxy-and-provider-translation.md` | `documentation--freshness-and-source-of-truth-rules.md` |
| Change browser/MCP/site analyzer behavior | `integration--desktop-mcp-browser-cana-view-site-analyzer-and-mac-control.md` | `security--credential-boundaries-rotation-and-known-risks.md` |
| Work on plans, knowledge, memory, or sync | `architecture--desktop-plan-documents-knowledge-and-behavioral-memory.md` | `architecture--cana-web-data-model-auth-tenancy-and-audit.md` |
| Change the hosted monorepo or route ownership | `architecture--cana-web-monorepo-web-api-and-package-boundaries.md` | `integration--remote-agents-chat-bus-and-cana-apps-runtime.md` |
| Change Prisma, authentication, tenancy, or audit | `architecture--cana-web-data-model-auth-tenancy-and-audit.md` | `security--credential-boundaries-rotation-and-known-risks.md` |
| Change remote agents, chat, schedules, bus, or Apps | `integration--remote-agents-chat-bus-and-cana-apps-runtime.md` | `operations--enterprise-helm-deployment-and-database-operations.md` |
| Deploy or operate production | `operations--enterprise-helm-deployment-and-database-operations.md` | `testing--builds-releases-and-verification.md` |
| Handle secrets, tokens, auth, or rotation | `security--credential-boundaries-rotation-and-known-risks.md` | Relevant subsystem article |
| Run checks or prepare a release | `testing--builds-releases-and-verification.md` | `documentation--freshness-and-source-of-truth-rules.md` |

### Complete catalogue

1. `architecture--cana-workspace-repository-map-and-ownership-boundaries.md`
2. `architecture--desktop-frontend-shell-state-and-navigation.md`
3. `architecture--desktop-tauri-rust-process-and-os-bridge.md`
4. `architecture--native-agent-runtime-turns-persistence-and-context.md`
5. `integration--agent-tools-permissions-aei-and-loom-orchestration.md`
6. `integration--desktop-llm-routing-proxy-and-provider-translation.md`
7. `integration--desktop-mcp-browser-cana-view-site-analyzer-and-mac-control.md`
8. `architecture--desktop-plan-documents-knowledge-and-behavioral-memory.md`
9. `architecture--cana-web-monorepo-web-api-and-package-boundaries.md`
10. `architecture--cana-web-data-model-auth-tenancy-and-audit.md`
11. `integration--remote-agents-chat-bus-and-cana-apps-runtime.md`
12. `operations--enterprise-helm-deployment-and-database-operations.md`
13. `security--credential-boundaries-rotation-and-known-risks.md`
14. `testing--builds-releases-and-verification.md`
15. `documentation--freshness-and-source-of-truth-rules.md`

### Freshness labels used here

- **Implemented snapshot:** verified directly against code at `last_verified`; re-check before changing behavior.
- **Live runbook:** operational instructions intended to be followed, but current CI/manifests still win.
- **Design-only:** a proposal, not evidence that runtime behavior exists.
- **Stale reference:** useful history whose counts, names, paths, or procedures have drifted.
- **Generated or vendored:** output with a canonical upstream and regeneration path; do not hand-edit.

## Key Decisions

- Keep one focused article per subsystem rather than one unmaintainable mega-document.
- Record exact repository-relative paths and useful symbols so a future agent can jump directly to authority.
- Keep security findings descriptive and redacted; never preserve credential values in knowledge.
- Treat the workspace-root library as cross-repository knowledge, not as product source.

## Constraints

- `last_verified` is a snapshot date, not a guarantee that branches remain unchanged.
- Git branches and version numbers are intentionally not treated as stable architecture.
- Some source comments encode incident history; they are valuable context but do not override executable behavior.
- Search this index after adding, removing, or renaming an article so the catalogue remains complete.
