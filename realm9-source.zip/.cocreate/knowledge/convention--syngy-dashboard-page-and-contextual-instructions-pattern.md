---
id: 51b2796d-c7e1-43be-9f55-b9b86021ba85
type: convention
tags: [ui, dashboard, instructions, sheet, page-header, forms, sites]
related_files: [src/components/forms/forms-page-client.tsx, src/components/forms/form-instructions.tsx, src/components/ui/page-header.tsx, src/app/(dashboard)/sites/sites-list.tsx]
confidence: 1
---
# Syngy dashboard page and contextual-instructions pattern

## Summary
Dashboard pages use PageContainer and PageHeader. Contextual help is implemented as an outline `Instructions` button with a BookOpen icon beside the primary action; it opens a right-side Sheet with a dedicated instruction component. The Forms page is the canonical implementation.

## Details
# Syngy dashboard page and contextual-instructions pattern

## Summary
Dashboard pages use PageContainer and PageHeader. Contextual help is implemented as an outline `Instructions` button with a BookOpen icon beside the primary action; it opens a right-side Sheet with a dedicated instruction component. The Forms page is the canonical implementation.

## Details
## Canonical page pattern
- Server route authenticates and resolves site access, then renders `PageContainer` plus a domain client component.
- Client component renders `PageHeader` with eyebrow, title, description, and an `actions` row.
- Secondary contextual help appears first as `<Button variant="outline">` with `BookOpen`; the primary create action appears second.
- Instruction content opens in `Sheet` using `SheetContent className="max-w-2xl"`, `SheetHeader`, `SheetTitle`, and `SheetBody`.
- Instruction content lives in a separate domain component rather than bloating the page component.

## Forms reference
`FormsPageClient` maintains `showInstructions`, renders Instructions beside New Form, and opens `FormInstructions`. `FormInstructions` uses short sections, platform/API tabs, and copyable code blocks.

## Sites application
The `/sites` page should mirror this exact interaction for setup onboarding: Instructions beside Add Site, opening site-setup guidance. Keep account signup/login out of this contextual guide because the user is already authenticated. Focus on creating a site, installing its generated tracking code, verifying activity, and optional integrations.

## Key Decisions
Reuse the existing Forms instruction affordance rather than inventing a new documentation layout. Contextual instructions belong at the point of action. Keep help secondary (outline) and creation primary.

## Constraints
Respect PageHeader’s existing action container and project design tokens. Preserve permission gating: `Add Site` is only available with `org:settings:write`. Do not expose site-specific secrets or IDs in generic pre-creation instructions.
