---
id: 206fbbb6-0f01-4307-b47c-b99263764a84
type: architecture
tags: [desktop, agent, python, sessions, context, persistence, compaction]
related_files: []
confidence: 1
---
# Native Agent Runtime Turns Persistence and Context

## Summary
The native agent is a Python sidecar whose protocol boundary is `unified_backend.py`. The backend, not the React window, owns the conversation and turn lifecycle. `SessionRegistry` isolates sessions and enforces execution ownership; `Agent` and the orchestrator implement model/tool loops; stores persist conversation and durable-run state. Context decisions use provider-observed token behavior and one summarizing compaction mechanism. Rotation is a fallback, not a second normal compaction path.

## Details

# Native Agent Runtime Turns Persistence and Context

## Summary

The native agent is a Python sidecar whose protocol boundary is `unified_backend.py`. The backend, not the React window, owns the conversation and turn lifecycle. `SessionRegistry` isolates sessions and enforces execution ownership; `Agent` and the orchestrator implement model/tool loops; stores persist conversation and durable-run state. Context decisions use provider-observed token behavior and one summarizing compaction mechanism. Rotation is a fallback, not a second normal compaction path.

## Details

### Process and protocol boundary

`src-agent/main.py` starts the sidecar and delegates its wire protocol to `unified_backend.py`. The Rust host connects over a local JSON-lines channel. Messages are envelopes with session identity and typed actions; events return readiness, streamed model content, thinking, tool requests/results, errors, interruption, context state, and completion.

The frontend must not infer turn completion from a missing stream chunk. It should react to explicit backend events routed through `src/services/agent/agent-event-router.ts`. Protocol additions need coordinated Python, Rust, TypeScript, and tests.

### Session registry and execution ownership

`session_registry.py` is the concurrency boundary. A session encapsulates configuration, conversation, runtime state, cancellation, pending approvals/tool calls, and task ownership. The registry separates session lookup/lifecycle from the agent algorithm and prevents two executors from advancing one session simultaneously.

Important invariants:

- A user-visible chat tab maps to a backend session identity.
- A turn has one executor even when messages, steering, interruptions, or wakeups arrive concurrently.
- Session shutdown cancels owned work and emits a terminal outcome.
- Backend restarts can reload durable state without replaying a completed side effect.
- Child sessions are distinct sessions with parent/role metadata, not threads inside the parent’s call stack.

Relevant tests include `test_backend_lifetime.py`, `test_run_session_single_executor.py`, `test_session_interrupt.py`, `test_session_wake.py`, and `test_claude_session_isolation.py`.

### Agent and turn loop

`agent.py` builds the effective agent and coordinates one turn. `orchestrator.py` handles iterative model calls, tool selection, tool execution/approval outcomes, streamed responses, retries, and stopping conditions. `messages.py`, `agent_events.py`, and `tool_registry.py` define the types and tool surface.

A normal turn conceptually proceeds:

1. Resolve live settings, model route, permission mode, tools, skills, project roots, and dynamic context.
2. Build the system/context prompt.
3. Send the current conversation state to the selected model route.
4. Stream assistant output and collect tool calls.
5. Classify each call by tool policy and permission state.
6. Execute automatically, request confirmation, deny, or hand off to a client as appropriate.
7. Append canonical tool outcomes and continue the model loop.
8. Persist the terminal assistant result and turn metadata.

Steering, injected messages, retries, user denial, and interruption are typed outcomes. Tests such as `test_agent_loop.py`, `test_retry_paths.py`, `test_user_steer.py`, `test_user_denial.py`, and `test_typed_outcomes.py` protect these branches.

### Prompt layering

`prompt_builder.py` composes policy and context from stable system instructions, application runtime rules, permission mode, tool schemas, selected skills, project knowledge, plans/todos, attachments, platform context, and dynamic session state. The order is security-sensitive: user/project material is context, not a higher-authority replacement for host policy.

`skill_selector.py`, `knowledge.py`, `platform_context.py`, and plan managers provide bounded inputs. Large or untrusted content must be labelled and budgeted. The bridge system prompt and child-agent prompt are separately tested.

### Persistence model

The runtime has distinct stores because their failure semantics differ:

- `persistence.py` and `session_store.py`: session messages/configuration and reloadable conversation state.
- `run_store.py`: durable run state, epochs, checkpoints, current action, and recovery metadata.
- Frontend chat-tab persistence: view/tab metadata only; it is not the canonical conversation store.

Persist transitions at idempotent boundaries. Do not mark a mutating tool completed before its result is durably recorded. Recovery must distinguish “never executed,” “executed with durable result,” and “unknown because the process died at the boundary.”

### Context accounting and compaction

`context_manager.py` owns token budgets, thresholds, compaction, and markers. The implementation uses provider-observed token counts when available and maintains an observed-to-estimated ratio for prediction. A fixed characters-per-token assumption is not authoritative across providers or tool-heavy transcripts.

The backend has one normal compaction strategy: summarize older context while preserving recent and load-bearing state. Rotation/chain advance is a fallback when the current session cannot continue safely. Do not add a third competing context mechanism.

Compaction must preserve:

- Active task/plan and acceptance criteria.
- Unresolved tool calls and evidence state.
- User decisions, current configuration, and relevant file paths.
- Explicit compaction markers so summaries are not recursively treated as raw history.
- Privacy boundaries: transient secrets and oversized tool output must not enter durable summaries.

See `test_context_manager.py`, `test_context_compaction.py`, `test_context_gate_wire.py`, `test_compaction_marker.py`, `test_dynamic_context.py`, and `test_truncation_budget.py`.

### Ordinary send versus explicit handoff

Since the backend owns history, ordinary chained sends should not carry a second frontend-supplied transcript. Full context transfer is reserved for deliberate transitions such as backend switch, fork, chain advance, or an explicit run action. Sending both backend history and frontend history duplicates tokens and can replay stale tool state.

### Source status

`docs/cana-agent-architecture.md` is a strong implemented snapshot and useful guide, but source modules and tests are authoritative. Design documents for remote/durable variants do not prove the native path has adopted their proposed behavior.

## Key Decisions

- Make the backend the sole conversation and turn authority; keep the window a view.
- Enforce one executor per session/run and use typed terminal outcomes.
- Separate session persistence, durable run recovery, and frontend tab metadata.
- Use provider-observed token accounting and one normal summarizing compaction mechanism.
- Treat prompt inputs as ordered trust layers rather than concatenated peer text.

## Constraints

- Protocol changes cross Python, Rust, TypeScript, and persisted-session compatibility boundaries.
- Model/provider token reporting is heterogeneous; estimation remains necessary but must be calibrated.
- Interrupted mutating tools can have unknown external outcomes and cannot always be retried safely.
- Compaction that omits acceptance criteria, pending action state, or user decisions can produce incorrect autonomous behavior.
- The packaged binary and development Python process must exercise equivalent protocol behavior.
