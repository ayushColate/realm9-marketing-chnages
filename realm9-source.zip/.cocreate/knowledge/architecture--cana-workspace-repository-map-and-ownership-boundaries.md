---
id: 1d972c46-0b10-4e51-be7b-a2b29688ccbc
type: architecture
tags: [cana, repositories, ownership, boundaries, source-of-truth]
related_files: []
confidence: 1
---
# Cana Workspace Repository Map and Ownership Boundaries

## Summary
Cana is a workspace of three independent Git repositories with different release and ownership roles. `cana-desktop` owns the installed client and the runtime images closely coupled to its native agent. `cana-web` owns the hosted application, API, data model, shared translation layer, public SDK, embed bundle, and mobile wrapper. `cana-web-enterprise` owns deploy-time desired state only. Cross-repository changes are explicit version or source-sync contracts, not a shared monorepo build.

## Details

# Cana Workspace Repository Map and Ownership Boundaries

## Summary

Cana is a workspace of three independent Git repositories with different release and ownership roles. `cana-desktop` owns the installed client and the runtime images closely coupled to its native agent. `cana-web` owns the hosted application, API, data model, shared translation layer, public SDK, embed bundle, and mobile wrapper. `cana-web-enterprise` owns deploy-time desired state only. Cross-repository changes are explicit version or source-sync contracts, not a shared monorepo build.

## Details

### `cana-desktop`: client and agent-runtime owner

Primary surfaces:

- React/Tailwind/Vite UI in `cana-desktop/src/`.
- Tauri/Rust host and operating-system bridges in `cana-desktop/src-tauri/src/`.
- Native Python agent in `cana-desktop/src-agent/`.
- Local model translation proxy in `cana-desktop/src-llm-proxy/`.
- Browser, cana-view, site-analyzer, and mac-control MCP servers in `cana-desktop/src-mcp/`.
- Remote runtime/container sources in `cana-desktop/RCA/`, `remote-claude-code/`, `rcc-internal/`, `rcc-autoscaler/`, and related runtime directories.
- Desktop release logic in `cana-desktop/ci/desktop-release.yml` and `scripts/`.

It uses npm at the root. Python dependencies are managed through root `pyproject.toml` and `scripts/uv-sync.sh`, with the environment at `src-agent/.venv`. Do not reintroduce ad-hoc pip installation as the normal setup path.

### `cana-web`: hosted product and shared platform owner

The pnpm/Turbo workspace includes `api`, `web`, and `packages/*`. Major ownership:

- Express API and long-lived bridges/workers: `cana-web/api/`.
- Next.js dashboard, admin, hosted Apps, public and auth surfaces: `cana-web/web/`.
- Prisma schema, database client, RBAC, audit, usage, and shared packages: `cana-web/packages/db/`.
- Public JavaScript SDK: `cana-web/packages/sdk-js/`.
- Private browser embed bundle: `cana-web/packages/embed-js/`.
- Search MCP image/source: `cana-web/search-mcp/`.
- Capacitor wrapper: `cana-web/mobile/`; it deliberately has its own npm toolchain and is not a pnpm workspace member.

The provider translation implementation under `api/src/services/translate/` is canonical. The desktop proxy carries a synchronized copy and must not become an independent fork.

### `cana-web-enterprise`: desired-state owner

This repository is an umbrella Helm chart plus subcharts and values. It does not build application code. Its core responsibilities are:

- Application, worker, Redis, search, ingress, RBAC, and service templates in `charts/cana-web/templates/`.
- PostgreSQL operator configuration in `charts/postgresql/`.
- Environment/version configuration in `values.yaml`.
- ArgoCD hook ordering and operational Kubernetes policy.

Application component versions are normally changed by CI in owning source repositories. Avoid hand-bumping bot-owned version fields. Infrastructure changes, secret references, probes, resources, scheduling, and database settings belong here.

### Cross-repository contracts

1. **Web image deployment:** `cana-web/.gitlab-ci.yml` builds an image and updates the web component version in enterprise values. Search MCP has a separate version cadence.
2. **Remote-agent images:** desktop CI builds remote runtimes and updates their enterprise repositories. The RCA deployment also updates the RCA image version consumed by the web API when it launches pods.
3. **Translator vendoring:** `cana-desktop/scripts/sync-llm-proxy-from-web.mjs` and `npm run llm:sync-web` copy the canonical web translate layer into `src-llm-proxy/src/translate/`; `.translate-source-sha` records the source revision.
4. **Design-kit synchronization:** desktop agent resources derive from the web API design-kit source. Treat the desktop copy as generated.
5. **Plan/project synchronization:** desktop state syncs with hosted models and routes, but desktop workspaces remain local-only. Repo URL normalization and project identity are a behavioral contract across implementations.
6. **Test-plan tooling:** similarly named sync scripts exist across repositories; if changing the contract, inspect both instead of assuming one is generated automatically.

### Generated, mirrored, or bot-owned paths

Do not hand-edit these without following their generator or upstream flow:

- `cana-desktop/src-llm-proxy/src/translate/**`.
- Bundled Tauri runtime resources under `cana-desktop/src-tauri/resources/agent`, `resources/llm-proxy`, and `resources/src-mcp`.
- Desktop agent design-kit copies.
- Build outputs such as `dist`, `.next`, `.turbo`, and Tauri targets.
- Architecture baselines except through the named update command.
- Enterprise component-version fields managed by source-repository CI.

Tracked third-party binaries and generated lockfiles require special care: “generated” does not imply safe to delete.

## Key Decisions

- Make each source repository authoritative for the artifacts it builds.
- Use explicit synchronization and revision pins for duplicated source.
- Keep infrastructure desired state separate from application source.
- Preserve local-only desktop workspace semantics even when project data syncs to the hosted platform.
- Check all three Git roots before and after cross-repository work; workspace-root Git commands do not represent them.

## Constraints

- The repositories can be on different branches and release cadences; never infer compatibility from branch names alone.
- A change to an Express route may also require enterprise ingress routing and desktop caller updates.
- Documentation sometimes contains old absolute paths and historical names. Use current repository structure and imports.
- Source mirrors can drift. Compare their pin or source hash before relying on parity.
