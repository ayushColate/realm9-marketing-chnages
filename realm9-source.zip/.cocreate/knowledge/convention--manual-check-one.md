---
id: ee144c9c-d8fb-438d-bf15-420ca82dc361
type: convention
tags: [manual-check, test-data, knowledge-base]
related_files: []
confidence: 1
---
# Manual check one

## Summary
A manually created knowledge entry named "Manual check one", added on request to confirm that an item can be created, named and structured correctly in this project's knowledge base. It carries no project guidance and should not be cited as a decision or convention.

## Details
# Manual check one

## Summary
A manually created knowledge entry named "Manual check one", added on request to confirm that an item can be created, named and structured correctly in this project's knowledge base. It carries no project guidance and should not be cited as a decision or convention.

## Details
The entry follows the project's knowledge convention: a `# Title` heading, then `## Summary`, then the optional `## Details`, `## Key Decisions` and `## Constraints` sections in that fixed order. Those headings are matched literally by the knowledge readers, so the layout is not cosmetic.

It was created through the knowledge API rather than by hand-writing a markdown file into `.cocreate/knowledge/`. A direct file write to that directory did not survive — the file reported as written was absent from disk immediately afterwards, so the directory is owned by the knowledge sync and should not be edited directly.

## Key Decisions
- Created via the knowledge API, not by writing markdown into `.cocreate/knowledge/` directly: a hand-written file there did not persist.
- Named itself as a manual check in its own Summary, so no future reader mistakes a placeholder for real project guidance.
- Verified by reading the entry back through the knowledge tools rather than by running a build; a test suite proves nothing about a document's content.

## Constraints
- This entry is a manual check. Do not cite it, extend it, or derive behaviour from it; deleting it is safe.
- Do not write knowledge files straight into `.cocreate/knowledge/` — that path is managed and direct writes are discarded.
- Never place credentials, tokens, or environment variable values in a knowledge entry; these files sync to the shared knowledge base.
