---
id: 8ed65628-a961-4d94-8db7-b4444523b957
type: implementation
tags: [pane-divider, resize, native-webview, preview, hit-testing, css-stacking, macos]
related_files: [src/lib/pane-seam.ts, src/lib/pane-seam.test.ts, src/lib/pane-divider-consistency.test.ts, src/index.css, src/components/browser/ai-browser-view.tsx, src/components/browser/devtools-resize.test.ts, src/components/layout/app-layout.tsx]
confidence: 1
---
# Preview pane dividers: the 23px native-webview grab area must never gate activation — seam-gated hover and drag

## Summary
The two Preview pane dividers (Browser↔DevTools, Browser↔Agent) carry a deliberately oversized 23px transparent ::before grab area because Preview is a native webview that paints above HTML and swallows the Preview-side half of a symmetric 7px target. That overhang is event capture only: hover highlight and pointer-down activation must be gated on the divider's own 1px seam rect via lib/pane-seam.ts, or the handle's arrow glyphs (~12-19px off-seam) both light the bar and start a resize. Shrinkin

## Details
# Preview pane dividers: the 23px native-webview grab area must never gate activation — seam-gated hover and drag

## Summary
The two Preview pane dividers (Browser↔DevTools, Browser↔Agent) carry a deliberately oversized 23px transparent ::before grab area because Preview is a native webview that paints above HTML and swallows the Preview-side half of a symmetric 7px target. That overhang is event capture only: hover highlight and pointer-down activation must be gated on the divider's own 1px seam rect via lib/pane-seam.ts, or the handle's arrow glyphs (~12-19px off-seam) both light the bar and start a resize. Shrinkin

## Details
# Preview pane dividers: the 23px native-webview grab area must never gate activation — seam-gated hover and drag

## Summary
The two Preview pane dividers (Browser↔DevTools, Browser↔Agent) carry a deliberately oversized 23px transparent ::before grab area because Preview is a native webview that paints above HTML and swallows the Preview-side half of a symmetric 7px target. That overhang is event capture only: hover highlight and pointer-down activation must be gated on the divider's own 1px seam rect via lib/pane-seam.ts, or the handle's arrow glyphs (~12-19px off-seam) both light the bar and start a resize. Shrinking ::before to fix the hover bug would reintroduce the dead-zone it exists to solve.

## Details
## The three-layer divider

Every pane divider in the app is ONE element with two pseudo-elements, defined once in `src/index.css`:

| Layer | Size | Role |
|---|---|---|
| element box (`.pane-divider` / `.pane-divider-row`) | **1px** | the visible seam/hyphen |
| `::before` | 7px baseline; **23px** on the two Preview modifiers | invisible grab target |
| `::after` | seam + 3px, one side only | the hover/drag highlight bar |

The element box IS the seam. This is the fact the fix turns on: "the pointer is on the seam" reduces exactly to "the pointer is within a few px of the element's own `getBoundingClientRect()` on the resize axis" — no extra markup, no measuring of the pseudo-elements (which are not in the layout box anyway).

## Why 23px exists (do not shrink it)

`.pane-divider-preview-agent::before { inset-inline: -3px -19px }` and
`.pane-divider-preview-devtools::before { inset-block: -3px -19px }`

Preview is a NATIVE webview (Tauri child), and a native layer always paints above HTML. A symmetric 7px grab area therefore loses its Preview-side half — the divider becomes uncatchable near that boundary. The `-19px` extends the target into the reliable HTML side only (into the Agent panel horizontally, into DevTools vertically). The visible seam stays 1px; only the transparent hit area grows.

The naive fix for the hover bug — shrink `::before` back to symmetric — reintroduces exactly that dead zone. `pane-divider-consistency.test.ts` pins the `-3px -19px` values for this reason.

## The defect

`.pane-divider:hover::after` hit-tests against `::before`, and `onPointerDown`/`onMouseDown` were bound to the element with no position check. Both therefore fired anywhere in the 23px band — including on the handle's up/down arrow glyphs ~12-19px off-seam. Users saw the divider highlight and resize from a spot visually unrelated to the seam.

## The fix: capture wide, activate narrow

`src/lib/pane-seam.ts` — `isPointerOnSeam(rect, point, axis)`, `SEAM_ACTIVATION_PX = 3`. `row` compares `clientY` against `top/bottom`; `column` compares `clientX` against `left/right`. Pure geometry, no DOM, unit-tested against the real arrow offsets.

1. **Pointer-down guard** runs FIRST in both handlers — before `preventDefault()`, the `setIsResizing*` flip, `syncBodyClass('resizing-panes')` and `setPointerCapture`. Returning early there leaves nothing half-started to clean up. `devtools-resize.test.ts` asserts that ordering by index comparison, so moving the guard below any of those fails the suite.
2. **Highlight** is driven by `data-seam-hot`, set from `onPointerMove`/`onPointerLeave` on the divider.
3. **CSS** suppresses `::after` for the two Preview modifiers when hovered off-seam:
   `.pane-divider-preview-*:hover:not([data-seam-hot="true"]):not([data-resizing="true"])::after { background-color: transparent; }`
   Every other divider in the app keeps plain `:hover`. `[data-resizing="true"]` is excluded so the bar stays lit for the whole drag as the pointer travels far from the seam.

## There is no draggable icon in our code

Searched the tree: no `GripHorizontal`, no `ChevronsUpDown` on a divider, no `::before`/`::after` content glyph, no `resize` CSS property on the divider or `.devtools-surface`. The divider renders a 1px line and two transparent pseudo-elements — nothing else.

The up/down arrow affordance visible near the DevTools seam is therefore NOT ours to gate: it is drawn outside our React tree (native/OS or embedded surface chrome). Anything asking to "show the icon only on the seam" cannot be satisfied by editing `.pane-divider`; the correct answer is that our highlight is already seam-gated, and the glyph has a different owner that must be identified before any change is promised.

## Key Decisions
1. Keep `::before` at 23px, gate activation separately — rather than shrinking the grab area. Shrinking is the obvious fix and is WRONG: the overhang is the native-webview dead-zone workaround, and `pane-divider-consistency.test.ts` pins its values deliberately.

2. Measure against the divider's own rect, not a new hover-probe element. The element box is already exactly the 1px seam, so no markup change is needed and the helper stays pure geometry (testable with plain objects, no DOM).

3. Guard BEFORE any side effect in the pointer-down handlers. An off-seam press must be a complete no-op: no `preventDefault`, no resizing state, no `resizing-panes` body class, no pointer capture — otherwise an off-seam click leaves a half-started drag with nothing to release it. Pinned by index-ordering assertions rather than a comment.

4. Scope the CSS override to the two Preview modifiers only, via `:not([data-seam-hot])`, instead of changing the shared `.pane-divider:hover` rule. Every other divider in the app (Plan, K8s, Settings, AI tab manager) keeps its existing 7px hover behavior — they have no native webview beside them and no oversized grab area, so they have no bug to fix.

5. Gate the Browser↔Agent handler on `data-seam-gated` rather than `classList.contains("pane-divider-preview-agent")`. The consistency test pins that class name to exactly ONE occurrence in `app-layout.tsx`; matching it in the handler added a second and broke the suite. The data attribute also keeps the guard independent of `appMode`, which is declared far below the handler in the component.

6. `SEAM_ACTIVATION_PX = 3` — wide enough to be catchable at the 1px seam, narrow enough to exclude arrows at 12px and 19px. A unit test asserts the constant stays under 19 so widening it later cannot silently reopen the bug.

## Constraints
- Do NOT shrink `.pane-divider-preview-agent::before` / `.pane-divider-preview-devtools::before` from `-3px -19px`. It is the macOS native-webview workaround and is pinned by `src/lib/pane-divider-consistency.test.ts`.
- The seam guard must stay the first statement after the button check in both handlers. Any side effect above it recreates the half-started-drag bug.
- `pane-divider-preview-agent` may appear exactly ONCE in `app-layout.tsx` (pinned by `.toHaveLength(1)`); do not reference the class name again in logic.
- `React.MouseEvent` alone has no `dataset` — the Browser↔Agent handler must be typed `React.MouseEvent<HTMLDivElement>`. Vitest does not catch this; only `npm run build` (tsc) does, so run the build, not just the tests.
- Effective grab target is now ~7px instead of 23px. An off-seam press inside the 23px area is still absorbed by `::before` (no fall-through to the pane beneath) — intentional, but a behavior change if fall-through is ever wanted.
- The Browser↔DevTools divider uses pointer events; Browser↔Agent uses mouse events. Do not unify them casually — the DevTools drag depends on `setPointerCapture` to survive crossing the native webview.
- No draggable-icon element exists in our source. Any request to gate "the handle icon" needs its real owner identified first; it cannot be done from `.pane-divider`.


## Key Decisions
1. Keep `::before` at 23px, gate activation separately — rather than shrinking the grab area. Shrinking is the obvious fix and is WRONG: the overhang is the native-webview dead-zone workaround, and `pane-divider-consistency.test.ts` pins its values deliberately.

2. Measure against the divider's own rect, not a new hover-probe element. The element box is already exactly the 1px seam, so no markup change is needed and the helper stays pure geometry (testable with plain objects, no DOM).

3. Guard BEFORE any side effect in the pointer-down handlers. An off-seam press must be a complete no-op: no `preventDefault`, no resizing state, no `resizing-panes` body class, no pointer capture — otherwise an off-seam click leaves a half-started drag with nothing to release it. Pinned by index-ordering assertions rather than a comment.

4. Scope the CSS override to the two Preview modifiers only, via `:not([data-seam-hot])`, instead of changing the shared `.pane-divider:hover` rule. Every other divider in the app (Plan, K8s, Settings, AI tab manager) keeps its existing 7px hover behavior — they have no native webview beside them and no oversized grab area, so they have no bug to fix.

5. Gate the Browser↔Agent handler on `data-seam-gated` rather than `classList.contains("pane-divider-preview-agent")`. The consistency test pins that class name to exactly ONE occurrence in `app-layout.tsx`; matching it in the handler added a second and broke the suite. The data attribute also keeps the guard independent of `appMode`, which is declared far below the handler in the component.

6. `SEAM_ACTIVATION_PX = 3` — wide enough to be catchable at the 1px seam, narrow enough to exclude arrows at 12px and 19px. A unit test asserts the constant stays under 19 so widening it later cannot silently reopen the bug.

## Constraints
- Do NOT shrink `.pane-divider-preview-agent::before` / `.pane-divider-preview-devtools::before` from `-3px -19px`. It is the macOS native-webview workaround and is pinned by `src/lib/pane-divider-consistency.test.ts`.
- The seam guard must stay the first statement after the button check in both handlers. Any side effect above it recreates the half-started-drag bug.
- `pane-divider-preview-agent` may appear exactly ONCE in `app-layout.tsx` (pinned by `.toHaveLength(1)`); do not reference the class name again in logic.
- `React.MouseEvent` alone has no `dataset` — the Browser↔Agent handler must be typed `React.MouseEvent<HTMLDivElement>`. Vitest does not catch this; only `npm run build` (tsc) does, so run the build, not just the tests.
- Effective grab target is now ~7px instead of 23px. An off-seam press inside the 23px area is still absorbed by `::before` (no fall-through to the pane beneath) — intentional, but a behavior change if fall-through is ever wanted.
- The Browser↔DevTools divider uses pointer events; Browser↔Agent uses mouse events. Do not unify them casually — the DevTools drag depends on `setPointerCapture` to survive crossing the native webview.
- No draggable-icon element exists in our source. Any request to gate "the handle icon" needs its real owner identified first; it cannot be done from `.pane-divider`.