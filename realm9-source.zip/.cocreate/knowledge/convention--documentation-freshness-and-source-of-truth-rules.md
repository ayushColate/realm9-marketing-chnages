---
id: 17961f7e-ba9b-4d7f-8c17-e4d6223174b8
type: convention
tags: [documentation, freshness, source-of-truth, design, runbooks]
related_files: []
confidence: 1
---
# Documentation Freshness and Source of Truth Rules

## Summary
Cana documentation has different authority levels. Source code, tests, schemas, executable configuration, and current Git history are authoritative for implemented behavior. A document’s explicit status determines how it may be used: an implemented snapshot explains code, a live runbook describes operations, a design proposal describes intent only, and a stale reference is historical orientation. File counts, line counts, version comments, paths, and old product names drift fastest and should ne

## Details

# Documentation Freshness and Source of Truth Rules

## Summary

Cana documentation has different authority levels. Source code, tests, schemas, executable configuration, and current Git history are authoritative for implemented behavior. A document’s explicit status determines how it may be used: an implemented snapshot explains code, a live runbook describes operations, a design proposal describes intent only, and a stale reference is historical orientation. File counts, line counts, version comments, paths, and old product names drift fastest and should never decide behavior without source verification.

## Details

### Authority order

Use this order when sources conflict:

1. Executed code, current schema, current manifest, and package/export configuration.
2. Tests that assert the behavior, understanding that unrun tests are specifications rather than evidence of a passing build.
3. Current source comments explaining load-bearing constraints or measured incidents.
4. Explicitly maintained implementation snapshot or operational runbook.
5. Design/proposal documents for intended future direction.
6. Project references, README boilerplate, historical comments, and generated reports.

Git history helps explain why a rule exists and whether a mirror is behind; it does not override current code.

### Strong current references

`docs/cana-agent-architecture.md` identifies itself as source-grounded and closely maps the implemented native agent. It is a strong orientation document, but protocol/store/tool modules and tests still win when details drift.

`docs/desktop-release-pipeline.md` is a live operational runbook. Use it together with `ci/desktop-release.yml`, bump scripts, Tauri configuration, and current pipeline variables. A runbook can describe an intended rollout step that has not yet been exercised on every platform.

`cana-desktop/CLAUDE.md` contains many incident-derived architecture decisions: cross-platform constraints, backend-owned conversation, compaction policy, window scoping, sync ownership, browser batching, and generated-source conventions. Some counts and paths inside it are stale, so use its decisions rather than numeric inventory.

### Design-only documents

`docs/rcc-durable-session-architecture.md` explicitly says it is not implemented. `docs/workspace-redesign.md` and several IDE gap documents are design proposals/specifications. They are useful for terminology, goals, threat models, and rejected alternatives, but they are not proof that routes, stores, migrations, or UI exist.

Before implementing a design, compare it to current code and current product direction; later partial work may have changed the feasible migration path.

### Known stale references

Examples found at the verified snapshot:

- `docs/project-reference.md` contains outdated setup instructions and older size/tool descriptions; its pip workflow conflicts with root uv policy.
- Desktop README content retains generic GitLab/template and old repository naming.
- Enterprise README is generic boilerplate and does not describe its ArgoCD desired-state purpose or bot-managed versions.
- Old absolute related-repository paths point to another username/case/path layout.
- Counts for large frontend files, commands, tests, models, and migrations have drifted.
- Enterprise `values.yaml` comments mention old component versions that no longer match values.
- Package names still carry prior product naming even though repository ownership changed.

Do not “fix” architecture to match these references. Update or label the documentation after verifying the current source.

### Generated and vendored documentation/data

Some files are generated contracts rather than authored explanations:

- Cana View selector catalogue generated from production source.
- Agent tool-registry snapshots.
- Architecture baseline updated by its named command.
- Test-plan sync output.
- Desktop’s vendored provider translation plus source revision pin.
- Bundled Tauri sidecar resources.

Use their generator and verify parity. Hand-editing may appear to work locally but be overwritten or create source/bundle disagreement.

### Freshness workflow for knowledge

When updating an article in this library:

1. Read every cited implementation file relevant to the change.
2. Search current symbols/routes rather than trusting stored line numbers.
3. Check recent Git history for moved ownership and incident fixes.
4. Compare generated/vendor pins with canonical upstream.
5. Label document evidence as implemented snapshot, runbook, design-only, stale, or generated.
6. Update `last_verified` only after source inspection.
7. Keep exact related file paths; avoid embedding volatile counts unless the count itself is a guarded contract.
8. Add a constraint/risk when a discrepancy remains unresolved.
9. Update `INDEX.md` when articles are added, removed, or renamed.
10. Run the structural/security validator and verify all three repository working trees.

### Writing rules

- State durable ownership, invariants, and failure modes rather than narrating every file.
- Use symbols and repository-relative paths; avoid absolute local usernames.
- Do not copy credentials, environment values, tokens, private URLs, user data, or raw production logs.
- Distinguish “code defines,” “test asserts,” “document proposes,” and “operator observed.”
- Include the reason for surprising rules when source comments provide it.
- Avoid stale future promises; link the design document and state that it is design-only.
- Record operational discrepancies as risks unless the task explicitly includes fixing them.

### High-churn zones requiring re-verification

- `AppLayout`, `AiPanel`, agent protocol/events, permission/AEI logic.
- Model catalogue/routing and the vendored translator pin.
- Apps run engine/store/recovery/evidence.
- Prisma schema, exports, auth middleware, and ingress prefixes.
- Enterprise component versions, probes, migration fallback, secret delivery, and TLS configuration.
- Release pipeline, signing, update bootstrap, and generated resources.

## Key Decisions

- Treat code/config/tests as authority and documents as classified evidence.
- Preserve explicit design-only status; never describe proposals as deployed behavior.
- Prefer durable invariants over volatile counts, branches, and version comments.
- Update knowledge only after direct source inspection and source-history reconciliation.
- Keep security-sensitive values out of documentation while still citing affected files and risks.

## Constraints

- Passing tests prove current behavior only if the tests were actually run at the inspected revision.
- Source comments can be stale too; compare them to executable values and imports.
- Some operational truth exists only in cluster/provider state and cannot be confirmed from repositories.
- Generated files may be authoritative output but not the place to originate changes.
- This library itself will drift unless `last_verified`, citations, and index coverage are maintained.
