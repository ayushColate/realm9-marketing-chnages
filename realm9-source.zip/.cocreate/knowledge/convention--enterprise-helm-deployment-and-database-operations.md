---
id: 74534113-574a-42d8-be47-8cfdd3982223
type: convention
tags: [enterprise, helm, kubernetes, argocd, postgres, redis, deployment]
related_files: []
confidence: 1
---
# Enterprise Helm Deployment and Database Operations

## Summary
`cana-web-enterprise` is the ArgoCD desired-state repository for the hosted stack. Its umbrella chart deploys the combined web/API pod, cron worker, Redis, search MCP/SearXNG, optional Nango and internal runtime, PostgreSQL operator resources, services, ingress, RBAC, and a PostSync Prisma schema job. It is not an application build repository. Rollback is normally a forward version change because deployments retain no ReplicaSet revision history.

## Details

# Enterprise Helm Deployment and Database Operations

## Summary

`cana-web-enterprise` is the ArgoCD desired-state repository for the hosted stack. Its umbrella chart deploys the combined web/API pod, cron worker, Redis, search MCP/SearXNG, optional Nango and internal runtime, PostgreSQL operator resources, services, ingress, RBAC, and a PostSync Prisma schema job. It is not an application build repository. Rollback is normally a forward version change because deployments retain no ReplicaSet revision history.

## Details

### Chart topology

The root `Chart.yaml` composes local `charts/cana-web` and `charts/postgresql` subcharts. `values.yaml` contains environment configuration, image versions, resource/scheduling policy, database settings, feature flags, and sensitive inputs. Application CI updates selected component-version fields; humans should avoid racing those bot-owned values during infrastructure work.

Main workloads include:

- Main Cana Deployment, normally multiple replicas.
- Cron worker, one replica with replacement semantics to prevent duplicate ticks.
- Redis with persistent volume.
- Search MCP with a SearXNG sidecar.
- Optional Nango and its public/admin ingress surfaces.
- Optional RCC-internal deployment.
- Prisma synchronization Job as an ArgoCD PostSync hook.
- Zalando PostgreSQL operator custom resource and database initialization job.

The Deployment hashes the rendered ConfigMap into the pod template so configuration changes roll pods even though `envFrom` alone would not.

### One pod, two services

The application image runs Express and Next as sibling processes. Two Kubernetes Services select the same pods but target different named ports. The ingress routes each prefix to the appropriate service. If either process exits, the container entrypoint stops the other, so health represents the pair.

Ingress order is a functional contract:

- Auth and cookie-resolving dashboard routes go to Next.
- Bearer, WebSocket, translation, and direct agent APIs go to Express.
- Some chat routes are direct Express while broader chat paths go through Next.
- RCA handoff uploads go direct to Express for byte integrity.
- Broad `/api` catch-all comes after specific exceptions.

Route changes require application and chart review together.

### Health, readiness, and drain

The API implements basic health and drain-aware readiness behavior. At the verified snapshot, the Deployment’s liveness and readiness probes both target `/health`, while the Express application exposes `/ready` to stop new traffic during graceful drain. This means Kubernetes readiness does not currently reflect the drain state. Treat it as an operational risk: a correct change should point readiness to the drain-aware endpoint while retaining a suitable liveness check, with rollout validation.

`api/src/lib/graceful-drain.ts` owns termination deadline and server draining. WebSocket and long-running agent connections require enough termination grace for clean handoff without routing new work to the pod.

### PostgreSQL and PgBouncer

Application traffic uses the operator pooler/PgBouncer endpoint. Schema operations use the direct PostgreSQL service because migration advisory locks, schema changes, and connection semantics are not safe through transaction pooling.

Incident-derived database settings include:

- On-demand node placement for database reliability rather than reclaimable capacity.
- Explicit resource requests based on measured use because autoscaler consolidation uses requests.
- WAL retention cap to prevent disk exhaustion from replication slots.
- Role/search-path initialization so pooled connections resolve the public schema correctly.
- Deliberate PDB handling: an additional overlapping PDB can make evictions impossible, while the application replicas need their own availability policy.

Preserve explanatory comments when tuning; they document reverted failures and production incidents.

### Prisma synchronization job

`prisma-migrate-job.yaml` is an ArgoCD PostSync hook at a later wave than database initialization. It waits for PostgreSQL, removes only unreferenced orphaned enum types after failed attempts, deletes failed migration records, connects directly, sets fail-fast shell behavior, and runs exactly one schema path.

At the verified snapshot, `packages/db/prisma/migrations` has no migration files, so the job takes the fallback path and runs `prisma db push --accept-data-loss`. Once migrations exist it runs `prisma migrate deploy` instead. This is a high-risk operational state because the fallback can apply destructive drift without reviewed migration history. Do not add an unconditional push after migrations; comments explain that this previously made migrations decorative.

The API separately checks a partial unique index required by the Apps run runtime because Prisma diff does not establish that index’s presence.

### Transitional seed behavior

`cana-web/entrypoint.sh` retains transitional seed-on-start behavior with a default-enabled environment switch and non-fatal errors. The chart did not explicitly set that switch at the verified snapshot, so every replica may attempt seeding on restart. The intended owner is the one-shot migration hook. Before disabling, ensure the hook performs required seed work; then set the application pods to skip it and verify idempotent rollout.

### Redis and workers

Redis supports coordination, locks/elections, caches, session/token refresh coordination, reminders, and agent run recovery. Persistence is enabled. Redis loss should not replace database truth for durable runs; database leases/epochs remain the authoritative fence.

Singleton-style workers use one replica and/or Redis election. Scaling a scheduler without understanding its election/idempotency can duplicate reminders, webhook delivery, expiry events, or cron runs.

### Release/version flow

Web CI builds the application and search images, copies them to the deployment registry, and updates separate enterprise version fields. Desktop CI updates the RCA image version consumed by the web API. Multiple CI jobs can write the same values file, using pull/rebase/push retries as a limited concurrency mitigation. Verify the exact value key and resulting pod image after deployment.

### Operational checklist

1. Confirm source image exists before changing desired state.
2. Inspect ArgoCD hook and sync-wave order.
3. Confirm ingress routes new endpoints to the right process/auth model.
4. Verify ConfigMap hash causes needed rollouts.
5. Check direct versus pooled database endpoint.
6. Observe migration Job output and schema guard.
7. Check readiness during drain and both Node processes.
8. Confirm singleton workers and Redis elections.
9. Verify secrets are sourced and rotated without printing them.
10. Prefer forward correction over relying on ReplicaSet rollback history.

## Key Decisions

- Keep deployment desired state in the enterprise repository and image builds in source repositories.
- Run Next and Express in one pod but expose process-specific Services and ordered ingress routes.
- Run schema synchronization as a direct-database PostSync Job, never in each application replica.
- Use measured resource/scheduling settings and preserve incident rationale.
- Treat Redis as coordination and PostgreSQL as durable authority.

## Constraints

- The current readiness probe mismatch can route traffic during graceful drain.
- The empty migration directory activates a destructive-schema fallback.
- Bot and human writes to shared values can conflict.
- `revisionHistoryLimit: 0` means rollback is a new desired-state change.
- Cluster state, secret rotation status, and actual external provider health cannot be proven from manifests alone.
