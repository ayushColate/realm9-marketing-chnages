---
id: 0377f37e-81bf-4991-82fd-eef525aac63b
type: general
tags: [test-data, fake, knowledge-base, verification]
related_files: []
confidence: 1
---
# knowledge tester 3

## Summary
Fourth deliberately fake knowledge entry, created to check that yet another hand-written item under `.cocreate/knowledge/` is stored, indexed and read back independently of the three that already exist. Everything below is invented and describes nothing in this repository. It is not project guidance, must not be cited, and is safe to delete at any time.

## Details
# knowledge tester 3

## Summary
Fourth deliberately fake knowledge entry, created to check that yet another hand-written item under `.cocreate/knowledge/` is stored, indexed and read back independently of the three that already exist. Everything below is invented and describes nothing in this repository. It is not project guidance, must not be cited, and is safe to delete at any time.

## Details
This entry sits alongside `note--knowledge-tester.md`, `note--knowledge-tester-two.md` and `note--knowledge-tester-2.md`, so the store holds four items. With titles that now differ only by a trailing token ("knowledge tester", "two", "2", "3"), a search that returns the wrong one — or merges any of them — is the defect this entry exists to expose.

Invented payload — none of this is real:

- A "tester-3" daemon watches an imaginary directory `var/fake-inbox/` and archives anything older than 30 minutes.
- Its configuration lives at `config/fake-tester-3.json` with a single key, `"tester_3": {"sweep_interval_s": 180}`.
- On a sweep failure it logs to `logs/fake-tester-3.log` and retries twice before giving up until the next interval.

Retrieval marker: KNOWLEDGE_TESTER_3_MARKER_9a1b

Searching for that marker is the cheapest way to confirm this fourth entry is stored and retrievable separately from the other three.

## Key Decisions
- **Use a fourth distinct marker rather than reusing any existing one.** Shared markers cannot tell "four entries stored" apart from "one entry matched four times".
- **Continue the near-colliding title series.** "knowledge tester 3" next to "2" and "two" keeps exercising title matching where the words are almost identical.
- **Keep the same section layout as the earlier entries.** Identical structure makes any difference in read-back a signal about the tooling, not about the files.
- **Give it a different invented payload.** Repeating an earlier payload would hide a de-duplication bug that silently collapses entries.
- **Verify by grepping the file, not by running a build.** The deliverable is a markdown document; a green test suite proves nothing about it.

## Constraints
- This file is test data. Do not cite it, extend it, or derive behaviour from it. Deleting it is safe and requires no cleanup elsewhere.
- Section order and heading text are position-sensitive: content is captured up to the next `## ` heading, so inserting a new `## ` heading between the existing ones truncates the preceding section.
- Never place credentials, tokens, or environment variable values in a knowledge entry; these files sync to the shared knowledge base.
