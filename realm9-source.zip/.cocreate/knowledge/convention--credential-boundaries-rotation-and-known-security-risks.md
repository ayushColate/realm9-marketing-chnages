---
id: 3f0b3df4-63aa-4a86-b3fb-da368a9b488a
type: convention
tags: [security, credentials, encryption, authentication, rotation, risk]
related_files: []
confidence: 1
---
# Credential Boundaries Rotation and Known Security Risks

## Summary
Credentials exist at several boundaries: desktop login/provider storage, local sidecar capabilities, hosted user/API/App/agent tokens, encrypted database payloads, CI cloud identity, and Kubernetes workload secrets. Values must never be copied into source, logs, knowledge, test fixtures, browser bundles, or model context. The enterprise repository currently contains plaintext production/service credential material in `values.yaml`; assume exposure, rotate affected credentials, scrub history as p

## Details

# Credential Boundaries Rotation and Known Security Risks

## Summary

Credentials exist at several boundaries: desktop login/provider storage, local sidecar capabilities, hosted user/API/App/agent tokens, encrypted database payloads, CI cloud identity, and Kubernetes workload secrets. Values must never be copied into source, logs, knowledge, test fixtures, browser bundles, or model context. The enterprise repository currently contains plaintext production/service credential material in `values.yaml`; assume exposure, rotate affected credentials, scrub history as policy requires, and migrate to an encrypted or external secret delivery mechanism.

## Details

### Credential classes and owners

- **Desktop user session credentials:** held by the authentication subsystem and used for hosted bearer calls. Definite expiry/invalidity may sign the user out; transient network or JWKS errors must not.
- **Desktop provider credentials:** stored through native/keyring and proxy configuration boundaries, never renderer persistence or logs.
- **Local capability tokens:** independent credentials for browser control/callback and LLM proxy channels; local-only and process-scoped.
- **Hosted API keys and App keys:** only hashes or encrypted forms persist as designed; raw values are shown once and belong in server-side configuration.
- **Bus/agent tokens:** hashed with a server-side pepper and scoped to agent/channel behavior.
- **Remote session credentials:** short-lived signed tokens bound to session, audience, and runtime purpose.
- **OAuth and connector credentials:** encrypted at rest; refresh/access material is write-only to clients and redacted from audits.
- **Data-encryption keys:** protect database payloads such as connections and App connector tokens. Rotation may require dual-read/reencryption rather than simple environment replacement.
- **CI/cloud credentials:** desktop release uses short-lived OIDC federation where configured; trust is pinned to protected project/ref context.
- **Kubernetes secrets:** workloads consume environment values through secret references, but the source of those secret objects must itself be protected.

### Confirmed enterprise exposure

`cana-web-enterprise/values.yaml` contains plaintext credential and encryption/session-secret material across provider, OAuth, data encryption, internal session, integration, search, and dashboard classes. Do not read or reproduce the values in tickets, chat, commits, knowledge, or terminal output. The chart renders a Kubernetes Secret from these inputs, but rendering them as a Secret does not protect the Git history that stores the plaintext source.

Response sequence:

1. Inventory affected credential classes without printing values.
2. Determine whether each has already been rotated out of band.
3. Rotate revocable provider/OAuth/session/internal credentials.
4. For encryption keys, follow a staged previous/current key runbook and re-encrypt dependent rows before removing the old key.
5. Invalidate sessions/tokens whose trust depends on rotated signing material.
6. Move source material to an external secret operator, encrypted values workflow, or equivalent audited system.
7. Remove plaintext from current Git and decide history-rewrite/retention response with repository owners.
8. Audit service logs and CI traces for accidental echoes.

Rotation cannot be declared complete from a Git diff; provider and cluster state must be checked.

### Encryption-key rotation gap

The hosted data-encryption implementation supports a prior-key environment variable for staged migration, and an operations document describes dual-key rotation. At the verified snapshot, the enterprise chart does not expose the prior-key input to the workload. This makes the documented production runbook incomplete. Add a secure optional prior-key reference, exercise dual-decrypt/new-encrypt migration, verify dependent row counts, then remove it after the old key is retired.

Never rotate an at-rest encryption key by overwriting the current value before dependent ciphertext is migrated. That can make stored connector/connection data unrecoverable.

### Process-wide TLS verification risk

The main Deployment sets `NODE_TLS_REJECT_UNAUTHORIZED=0` process-wide to accommodate a self-signed database/pooler certificate. That weakens certificate verification for all outbound Node HTTPS, including provider, billing, OAuth, webhook, and MCP traffic. Scope the database exception to the database connection configuration or trusted CA bundle instead. The Nango deployment contains an example of rejecting the global flag and handling database TLS in its connection string.

Treat removal as a tested deployment change: configure the correct CA or database-specific mode, verify database connectivity, then assert unrelated HTTPS remains verified.

### Authentication boundaries

- Dashboard browser traffic uses Auth.js database cookies.
- Desktop and agents use Origin9 bearer credentials.
- API keys are a distinct principal and must be owner/revoke/expiry checked.
- Internal cron impersonation requires a secret handshake plus an acting user and must stay cluster-internal/audited.
- App visitors combine signed identity, origin policy, replay protection, and App access mode.
- Remote pods combine session credentials with durable user/session authorization.
- Dual-auth bus/boards routes explicitly distinguish user and agent principals.

Do not pass organization, owner, or user ids as model-controlled tool arguments. Resolve them from the authenticated caller and database membership.

### Secret-safe development and testing

- Use protected-path enforcement; do not attempt alternate shell, encoding, symlink, or browser-profile routes.
- Keep local environment, key, certificate, session fixture, and live model files ignored.
- Redact authorization headers, cookies, query credentials, connector headers, prompts containing secrets, and provider response metadata.
- Use placeholders that cannot be mistaken for live provider credentials.
- Scan staged diffs and generated artifacts before commit.
- Never place server App credentials in browser code; use server-side SDK calls or visitor credentials designed for the embed.
- Connector headers are write-only; APIs should report status/label/expiry, not stored values.

### CI credential risk

Prefer workload identity/OIDC over long-lived CI secrets. Current source history also contains hard-coded registry login material in CI configuration. Treat it like the enterprise values exposure: rotate, remove, and replace with a scoped CI variable or identity-based registry flow. Do not preserve the literal value in remediation notes.

### Audit and retention

Credential audit logs should record actor, credential class, resource, action, outcome, timestamp, and safe identifiers—not the credential, ciphertext, authorization header, or full provider payload. Security events must be retained and access-controlled separately from ordinary diagnostic logs.

## Key Decisions

- Assume committed plaintext credentials are exposed even in a private/self-hosted repository.
- Rotate revocable credentials and use staged reencryption for at-rest encryption keys.
- Replace Git-stored secret material with encrypted/external delivery and short-lived identities.
- Scope TLS exceptions to the one connection that needs them; never disable verification process-wide.
- Derive authorization scope from authenticated context, not model/client arguments.

## Constraints

- Rotation status and credential activity require provider/cluster access not available from source inspection.
- Git history can retain removed values; deleting one line is not full remediation.
- Encryption-key rotation can cause irreversible data loss if dependent rows are not migrated.
- Some remote/browser/mobile flows need multiple credential types, but those types must remain independently scoped.
- Security knowledge must cite locations and classes only, never values or recognizable credential fragments.
