---
plan_id: 134b9384
status: completed
created_at: 2026-09-24T00:09:52.254352
---

# Realm9 Landing Page Content Enhancement

## Goal
Rewrite the realm9-newNextJS landing page (app/page.tsx) to accurately reflect Realm9's actual capabilities from colate/realm9. Remove StatBand metrics strip with unsupported claims (GCP, OCI, &lt;10 min). Rewrite hero description to emphasize lease-based governance and unified ledger. Update FeatureRow cloud provider claims from "AWS, Azure, GCP and OCI" to "AWS, Azure" only. Remove "in ten minutes" from CtaBand. Success: npm run build passes, StatBand removed, GCP/OCI references gone, timing claims removed, hero refocused on governance value.

## Context
**Verified Capabilities (colate/realm9/FEATURE_MAP.md line 44):**
- Cloud providers: AWS, Azure, on-prem (Proxmox + vSphere)
- NOT supported: GCP, OCI
- Audit categories: 16 actual (auth, sso, users, sessions, security, scim, environments, bookings, decommission, terraform, workflows, system, fieldMapping, finops, git, servicenow)
- No "&lt;10 min" timing found in documentation
- Self-hosted: Supported via Docker/Kubernetes

**Landing Page Issues (app/page.tsx):**
1. Lines 22-27: StatBand with unsupported claims ("4 clouds" GCP/OCI, "&lt;10 min" timing)
2. Line 13: Hero sub is generic sales copy, doesn't communicate lease/ledger governance
3. Line 65: FeatureRow 2 mentions "AWS, Azure, GCP and OCI" — GCP/OCI unsupported
4. Line 122: CtaBand says "in ten minutes" — timing unverified

**Changes Required:**
1. Remove StatBand import (line 1) and usage (lines 22-27)
2. Replace Hero sub (line 13) with: "Request infrastructure as humans, agents or pipelines — with identity, approval, quota and cost tracking at every step. One policy engine, one ledger, one control plane from request to consumption."
3. Update FeatureRow 2 line 65 body from "across AWS, Azure, GCP and OCI, and across" to "across AWS, Azure, and across"
4. Update CtaBand line 122 from "Deploy it on your own hardware in ten minutes" to "Deploy it on your own hardware"

## Key Files
- `app/page.tsx`

## Approach

**Step 1: Remove StatBand Import and Component**
- Edit line 1: Delete 'StatBand' from import statement
- Edit lines 22-27: Delete entire StatBand component with stats array containing unsupported cloud claims and timing

**Step 2: Rewrite Hero Sub-Description**
- Edit line 13: Replace generic text with governance-focused messaging emphasizing lease-based governance and unified ledger

**Step 3: Fix Cloud Provider Claims in FeatureRow 2**
- Edit line 65: Remove "GCP and OCI," from FeatureRow 2 body text

**Step 4: Remove Timing Claim from CtaBand**
- Edit line 122: Delete "in ten minutes" from CtaBand title

**Step 5: Build and Verify**
- Run npm run build to confirm no compilation errors
- Verify StatBand removed, cloud claims fixed, timing removed


## Verification
All todos pass: (1) StatBand grep returns 1, (2) 'One policy engine, one ledger' found, (3) 'AWS, Azure, and across the vCenter and Proxmox' found, (4) CtaBand title grep succeeds, (5) npm run build exits 0

## Todos
- [b7a38f14] Remove StatBand import and component
- [21cee5fc] Rewrite Hero sub-description
- [fdffae65] Remove GCP/OCI from FeatureRow 2
- [26892ccb] Remove timing claim from CtaBand
- [c5d062c6] Verify build succeeds
