# Rewrite Hero sub-description

Edit app/page.tsx line 13. Replace with: 'Request infrastructure as humans, agents or pipelines — with identity, approval, quota and cost tracking at every step. One policy engine, one ledger, one control plane from request to consumption.'
