# Remove GCP/OCI from FeatureRow 2

Edit app/page.tsx line 65. Change from 'across AWS, Azure, GCP and OCI, and across' to 'across AWS, Azure, and across'
